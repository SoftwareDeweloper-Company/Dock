/* ------------------------------------------------------------------
   HYPER SNAKE — rendering + simulation engine
   Canvas 2D, cached lighting sprites, procedural arena, 60 fps loop.
------------------------------------------------------------------- */

export type GameState = "ready" | "playing" | "paused" | "dead";
export type Quality = "ultra" | "balanced" | "lite";

export interface EngineOptions {
  wrap: boolean;
  sound: boolean;
  quality: Quality;
}

export interface HudSnapshot {
  state: GameState;
  score: number;
  best: number;
  length: number;
  speed: number;
  apples: number;
  combo: number;
  comboFrac: number;
  fps: number;
  wrap: boolean;
  newRecord: boolean;
}

const TAU = Math.PI * 2;
const clamp = (v: number, lo: number, hi: number) => (v < lo ? lo : v > hi ? hi : v);
const mod = (v: number, m: number) => ((v % m) + m) % m;

const QUALITY: Record<Quality, { dpr: number; particles: number; ambient: number; detail: number }> = {
  ultra: { dpr: 1.75, particles: 1, ambient: 1, detail: 1 },
  balanced: { dpr: 1.3, particles: 0.72, ambient: 0.65, detail: 0.8 },
  lite: { dpr: 0.9, particles: 0.42, ambient: 0.3, detail: 0.5 },
};

const BEST_KEY = "hyperSnake.best.v2";
const OPTION_KEY = "hyperSnake.options.v2";

export function loadOptions(): EngineOptions {
  const coarsePointer =
    typeof window !== "undefined" && window.matchMedia ? window.matchMedia("(pointer: coarse)").matches : false;
  const fallback: EngineOptions = { wrap: false, sound: true, quality: coarsePointer ? "balanced" : "ultra" };
  try {
    const raw = localStorage.getItem(OPTION_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as Partial<EngineOptions>;
    return {
      wrap: Boolean(parsed.wrap),
      sound: parsed.sound !== false,
      quality:
        parsed.quality === "balanced" || parsed.quality === "lite" || parsed.quality === "ultra"
          ? parsed.quality
          : "ultra",
    };
  } catch {
    return fallback;
  }
}

export function saveOptions(options: EngineOptions) {
  try {
    localStorage.setItem(OPTION_KEY, JSON.stringify(options));
  } catch {
    /* storage may be unavailable */
  }
}

export function loadBest(): number {
  try {
    return Number(localStorage.getItem(BEST_KEY) || 0) || 0;
  } catch {
    return 0;
  }
}

function saveBest(value: number) {
  try {
    localStorage.setItem(BEST_KEY, String(value));
  } catch {
    /* ignore */
  }
}

type Vec = { x: number; y: number };
type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  rgb: string;
  gravity: number;
};
type Ring = { x: number; y: number; t: number; life: number; rgb: string; width: number };
type Pop = { x: number; y: number; vy: number; t: number; text: string; rgb: string; scale: number };
type Mote = { x: number; y: number; r: number; phase: number; speed: number; drift: number };

const PARTICLE_RGB = [
  "255,232,150",
  "255,154,86",
  "196,255,142",
  "255,120,120",
  "174,255,190",
  "255,214,92",
  "255,247,224",
];

function makeRng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export class HyperSnakeGame {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private onHud: (hud: HudSnapshot) => void;

  private W = 0;
  private H = 0;
  private dpr = 1;
  private renderScale = 1;
  private lastScaleShift = 0;
  private CS = 24;
  private R = 11;

  options: EngineOptions;
  state: GameState = "ready";
  score = 0;
  best = loadBest();
  apples = 0;
  combo = 1;
  comboT = 0;
  private foodIndex = 0;
  private newRecord = false;
  private bestAtStart = 0;

  private hx = 0;
  private hy = 0;
  private dx = 1;
  private dy = 0;
  private queue: Vec[] = [];
  private distSinceTurn = 0;
  private trail: Vec[] = [];
  private bodyPts: Vec[] = [];
  private bodyLen = 0;
  private baseSpeed = 0;
  private speedMult = 1;
  private speed = 0;

  private food: { x: number; y: number; kind: "apple" | "golden" } = { x: 0, y: 0, kind: "apple" };

  private particles: Particle[] = [];
  private rings: Ring[] = [];
  private pops: Pop[] = [];
  private motes: Mote[] = [];

  private t = 0;
  private shake = 0;
  private flash = 0;
  private newRecordFlash = 0;

  private raf = 0;
  private lastFrame = 0;
  private fps = 60;
  private fpsAcc = 0;
  private fpsFrames = 0;
  private lastHudAt = 0;
  private aiTimer = 0;

  private bg: HTMLCanvasElement | null = null;
  private glows = new Map<string, HTMLCanvasElement>();
  private headCache: { key: string; canvas: HTMLCanvasElement; size: number } | null = null;
  private foodCache = new Map<string, { canvas: HTMLCanvasElement; size: number }>();
  private audio: AudioContext | null = null;
  private visibilityHandler: () => void;
  private destroyed = false;

  constructor(
    canvas: HTMLCanvasElement,
    width: number,
    height: number,
    options: EngineOptions,
    onHud: (hud: HudSnapshot) => void
  ) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) throw new Error("Canvas 2D is not available");
    this.ctx = ctx;
    this.options = { ...options };
    this.onHud = onHud;
    this.resize(width, height);
    this.visibilityHandler = () => {
      if (document.hidden && this.state === "playing") this.pause();
    };
    document.addEventListener("visibilitychange", this.visibilityHandler);
    this.lastFrame = performance.now();
    this.raf = requestAnimationFrame(this.tick);
    this.emitHud(true);
  }

  /* ------------------------------------------------------------ sizing */
  resize(width: number, height: number) {
    const w = Math.max(220, Math.round(width));
    const h = Math.max(220, Math.round(height));
    const first = this.W === 0;
    const oldW = this.W || w;
    const oldH = this.H || h;
    const oldCS = this.CS;

    if (!first && (Math.abs(oldW - w) > 1 || Math.abs(oldH - h) > 1)) {
      this.rescale(w / oldW, h / oldH);
    }

    this.W = w;
    this.H = h;
    const cfg = QUALITY[this.options.quality];
    this.dpr = Math.max(0.6, Math.min(window.devicePixelRatio || 1, cfg.dpr) * this.renderScale);
    this.canvas.width = Math.round(w * this.dpr);
    this.canvas.height = Math.round(h * this.dpr);

    this.CS = clamp(Math.min(w, h) / 20.5, 17, 34);
    this.R = this.CS * 0.47;
    this.baseSpeed = this.CS * 5.35;

    if (first) {
      this.bodyLen = this.CS * 6;
      this.reset("ready");
    } else {
      this.bodyLen = (this.bodyLen / (oldCS || this.CS)) * this.CS;
      this.speed = this.baseSpeed * this.speedMult;
      if (!this.options.wrap) {
        const safe = this.edge();
        this.hx = clamp(this.hx, safe, Math.max(safe, w - safe));
        this.hy = clamp(this.hy, safe, Math.max(safe, h - safe));
      }
      this.buildBodyPoints();
      this.clampFood();
    }

    this.glows.clear();
    this.headCache = null;
    this.foodCache.clear();
    this.buildBackground();
    this.buildMotes();
    this.emitHud(true);
  }

  private rescale(sx: number, sy: number) {
    if (!isFinite(sx) || !isFinite(sy) || sx <= 0 || sy <= 0) return;
    this.hx *= sx;
    this.hy *= sy;
    this.fx *= sx;
    this.fy *= sy;
    for (const p of this.trail) {
      p.x *= sx;
      p.y *= sy;
    }
    for (const p of this.particles) {
      p.x *= sx;
      p.y *= sy;
    }
    for (const r of this.rings) {
      r.x *= sx;
      r.y *= sy;
    }
    for (const p of this.pops) {
      p.x *= sx;
      p.y *= sy;
    }
    this.queue.length = 0;
    this.distSinceTurn = 0;
  }

  private get fx() {
    return this.food.x;
  }
  private set fx(v: number) {
    this.food.x = v;
  }
  private get fy() {
    return this.food.y;
  }
  private set fy(v: number) {
    this.food.y = v;
  }

  /* ------------------------------------------------------------- audio */
  private ensureAudio(): AudioContext | null {
    if (!this.options.sound) return null;
    try {
      if (!this.audio) {
        const Ctor =
          window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!Ctor) return null;
        this.audio = new Ctor();
      }
      if (this.audio.state === "suspended") void this.audio.resume();
      return this.audio;
    } catch {
      return null;
    }
  }

  private tone(freq: number, duration: number, type: OscillatorType, volume: number, delay = 0, slide = 0) {
    const ac = this.ensureAudio();
    if (!ac) return;
    try {
      const start = ac.currentTime + delay;
      const osc = ac.createOscillator();
      const gain = ac.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(Math.max(30, freq), start);
      if (slide !== 0) {
        osc.frequency.exponentialRampToValueAtTime(Math.max(35, freq + slide), start + duration);
      }
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, volume), start + 0.013);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
      osc.connect(gain);
      gain.connect(ac.destination);
      osc.start(start);
      osc.stop(start + duration + 0.05);
    } catch {
      /* audio is optional */
    }
  }

  private soundEat(golden: boolean) {
    if (golden) {
      this.tone(660, 0.1, "triangle", 0.09);
      this.tone(880, 0.12, "triangle", 0.08, 0.07);
      this.tone(1320, 0.18, "sine", 0.06, 0.14);
    } else {
      this.tone(450 + Math.random() * 50, 0.09, "triangle", 0.075);
      this.tone(700, 0.1, "sine", 0.05, 0.055);
    }
  }

  private soundDeath() {
    this.tone(220, 0.32, "sawtooth", 0.1, 0, -150);
    this.tone(120, 0.5, "sine", 0.1, 0.09, -60);
  }

  /* -------------------------------------------------------------- setup */
  private edge() {
    return Math.max(14, this.R * 1.15 + 7);
  }

  reset(state: GameState) {
    this.state = state;
    this.score = 0;
    this.apples = 0;
    this.foodIndex = 0;
    this.combo = 1;
    this.comboT = 0;
    this.speedMult = 1;
    this.speed = this.baseSpeed * (state === "ready" ? 0.82 : 1);
    this.bodyLen = this.CS * 6;
    this.newRecord = false;
    this.flash = 0;
    this.shake = 0;
    this.queue = [];
    this.distSinceTurn = this.R * 1.3;
    this.particles = [];
    this.rings = [];
    this.pops = [];

    const span = this.bodyLen + this.CS * 3;
    const minX = Math.min(this.W - this.edge() - this.CS, span + this.edge());
    this.hx = clamp(this.W * 0.52, minX, this.W - this.edge() - this.CS);
    this.hy = this.H * 0.5;
    this.dx = 1;
    this.dy = 0;
    this.trail = [];
    for (let d = span; d >= 0; d -= 1.35) {
      this.trail.push({ x: this.hx - d, y: this.hy });
    }
    this.buildBodyPoints();
    this.spawnFood();
    this.buildBodyPoints();
    this.emitHud(true);
  }

  start() {
    this.bestAtStart = this.best;
    this.ensureAudio();
    this.reset("playing");
    this.tone(520, 0.08, "sine", 0.06);
    this.tone(780, 0.12, "sine", 0.05, 0.07);
  }

  restart() {
    this.start();
  }

  menu() {
    this.reset("ready");
  }

  pause() {
    if (this.state !== "playing") return;
    this.state = "paused";
    this.queue.length = 0;
    this.emitHud(true);
  }

  resume() {
    if (this.state !== "paused") return;
    this.state = "playing";
    this.lastFrame = performance.now();
    this.ensureAudio();
    this.emitHud(true);
  }

  togglePause() {
    if (this.state === "playing") this.pause();
    else if (this.state === "paused") this.resume();
  }

  turn(x: number, y: number) {
    if (this.state !== "playing" && this.state !== "ready") return;
    if (x === 0 && y === 0) return;
    const last = this.queue.length > 0 ? this.queue[this.queue.length - 1] : { x: this.dx, y: this.dy };
    if (x === -last.x && y === -last.y) return;
    if (x === last.x && y === last.y) return;
    if (this.queue.length < 2) this.queue.push({ x, y });
  }

  /** Turn toward a point in canvas coordinates (used by mouse steering). */
  steerTowards(x: number, y: number) {
    if (this.state !== "playing") return;
    const head = this.headPos();
    const dx = this.wdx(x - head.x);
    const dy = this.wdy(y - head.y);
    if (Math.abs(dx) < 4 && Math.abs(dy) < 4) return;
    if (Math.abs(dx) > Math.abs(dy)) this.turn(dx > 0 ? 1 : -1, 0);
    else this.turn(0, dy > 0 ? 1 : -1);
  }

  setOptions(next: EngineOptions) {
    const prevQuality = this.options.quality;
    const prevWrap = this.options.wrap;
    this.options = { ...next };
    if (next.quality !== prevQuality) {
      const cfg = QUALITY[next.quality];
      this.dpr = Math.max(0.6, Math.min(window.devicePixelRatio || 1, cfg.dpr) * this.renderScale);
      this.canvas.width = Math.round(this.W * this.dpr);
      this.canvas.height = Math.round(this.H * this.dpr);
      this.glows.clear();
      this.headCache = null;
      this.foodCache.clear();
      this.buildBackground();
      this.buildMotes();
    }
    if (next.wrap !== prevWrap) {
      this.queue.length = 0;
      this.hx = mod(this.hx, this.W);
      this.hy = mod(this.hy, this.H);
      for (const p of this.trail) {
        p.x = mod(p.x, this.W);
        p.y = mod(p.y, this.H);
      }
      if (!next.wrap) {
        const safe = this.edge();
        this.hx = clamp(this.hx, safe, Math.max(safe, this.W - safe));
        this.hy = clamp(this.hy, safe, Math.max(safe, this.H - safe));
      }
      this.buildBodyPoints();
    }
    this.emitHud(true);
  }

  destroy() {
    this.destroyed = true;
    cancelAnimationFrame(this.raf);
    document.removeEventListener("visibilitychange", this.visibilityHandler);
    if (this.audio) {
      try {
        void this.audio.close();
      } catch {
        /* noop */
      }
    }
  }

  /* ----------------------------------------------------------- geometry */
  private wdx(dx: number) {
    if (!this.options.wrap) return dx;
    if (dx > this.W * 0.5) return dx - this.W;
    if (dx < -this.W * 0.5) return dx + this.W;
    return dx;
  }

  private wdy(dy: number) {
    if (!this.options.wrap) return dy;
    if (dy > this.H * 0.5) return dy - this.H;
    if (dy < -this.H * 0.5) return dy + this.H;
    return dy;
  }

  private dist(ax: number, ay: number, bx: number, by: number) {
    const dx = this.wdx(bx - ax);
    const dy = this.wdy(by - ay);
    return Math.hypot(dx, dy);
  }

  private dist2(ax: number, ay: number, bx: number, by: number) {
    const dx = this.wdx(bx - ax);
    const dy = this.wdy(by - ay);
    return dx * dx + dy * dy;
  }

  private buildBodyPoints() {
    const n = this.trail.length;
    const pts: Vec[] = [];
    const spacing = Math.max(1.6, this.R * 0.32);
    let target = 0;
    let acc = 0;
    for (let i = n - 1; i > 0; i--) {
      const ax = this.trail[i].x;
      const ay = this.trail[i].y;
      const ddx = this.wdx(this.trail[i - 1].x - ax);
      const ddy = this.wdy(this.trail[i - 1].y - ay);
      const seg = Math.hypot(ddx, ddy);
      if (seg > 1e-6) {
        while (acc + seg >= target && target <= this.bodyLen) {
          const k = (target - acc) / seg;
          let x = ax + ddx * k;
          let y = ay + ddy * k;
          if (this.options.wrap) {
            x = mod(x, this.W);
            y = mod(y, this.H);
          }
          pts.push({ x, y });
          target += spacing;
          if (pts.length > 480) break;
        }
      }
      acc += seg;
      if (acc > this.bodyLen + spacing * 2) break;
    }
    if (pts.length === 0) {
      const head = this.headPos();
      pts.push({ x: head.x, y: head.y });
    }
    this.bodyPts = pts;
  }

  private headPos(): Vec {
    return { x: this.options.wrap ? mod(this.hx, this.W) : this.hx, y: this.options.wrap ? mod(this.hy, this.H) : this.hy };
  }

  private spawnFood() {
    const margin = this.R * 3 + 12;
    for (let attempt = 0; attempt < 260; attempt++) {
      const x = margin + Math.random() * Math.max(1, this.W - margin * 2);
      const y = margin + Math.random() * Math.max(1, this.H - margin * 2);
      const head = this.headPos();
      if (this.dist(head.x, head.y, x, y) < this.R * 5.2) continue;
      let bad = false;
      for (let i = 0; i < this.bodyPts.length; i += 2) {
        if (this.dist(this.bodyPts[i].x, this.bodyPts[i].y, x, y) < this.R * 1.9) {
          bad = true;
          break;
        }
      }
      if (bad) continue;
      this.food = { x, y, kind: this.foodIndex > 0 && this.foodIndex % 5 === 0 ? "golden" : "apple" };
      return;
    }
    this.food = { x: this.W * 0.72, y: this.H * 0.35, kind: "apple" };
  }

  private clampFood() {
    const margin = this.R * 2.4;
    this.food.x = clamp(this.food.x, margin, Math.max(margin, this.W - margin));
    this.food.y = clamp(this.food.y, margin, Math.max(margin, this.H - margin));
  }

  /* ---------------------------------------------------------- simulation */
  private advance(dt: number) {
    const step = this.speed * dt;
    this.distSinceTurn += step;
    if (this.queue.length > 0 && this.distSinceTurn >= this.R * 1.15) {
      const d = this.queue.shift();
      if (d && !(d.x === -this.dx && d.y === -this.dy)) {
        this.dx = d.x;
        this.dy = d.y;
      }
      this.distSinceTurn = 0;
    }

    this.hx += this.dx * step;
    this.hy += this.dy * step;
    const edge = this.edge();

    if (this.options.wrap) {
      this.hx = mod(this.hx, this.W);
      this.hy = mod(this.hy, this.H);
    } else if (this.hx < edge || this.hx > this.W - edge || this.hy < edge || this.hy > this.H - edge) {
      this.die();
      return;
    }

    const last = this.trail[this.trail.length - 1];
    if (!last || Math.hypot(this.hx - last.x, this.hy - last.y) > 0.85) {
      this.trail.push({ x: this.hx, y: this.hy });
    }

    const need = this.bodyLen + this.CS * 6;
    let acc = 0;
    let i = this.trail.length - 1;
    while (i > 0 && acc < need) {
      acc += this.dist(this.trail[i].x, this.trail[i].y, this.trail[i - 1].x, this.trail[i - 1].y);
      i--;
    }
    if (i > 1) this.trail.splice(0, i);
  }

  private runAI(dt: number) {
    this.aiTimer -= dt;
    if (this.aiTimer > 0 || this.queue.length > 0) return;
    if (this.distSinceTurn < this.R * 1.4) return;
    this.aiTimer = 0.05;

    const dirs: Vec[] = [
      { x: 0, y: -1 },
      { x: 0, y: 1 },
      { x: -1, y: 0 },
      { x: 1, y: 0 },
    ];
    const head = this.headPos();
    const foodDist = this.dist(head.x, head.y, this.food.x, this.food.y);
    const edge = this.edge();
    type Candidate = { d: Vec; score: number; clearance: number };
    const candidates: Candidate[] = [];

    const clearanceAt = (x: number, y: number) => {
      let nearest = this.CS * 7;
      for (let i = 10; i < this.bodyPts.length; i += 2) {
        const dx = this.wdx(x - this.bodyPts[i].x);
        const dy = this.wdy(y - this.bodyPts[i].y);
        const d = Math.hypot(dx, dy);
        if (d < nearest) nearest = d;
      }
      return nearest;
    };

    for (const d of dirs) {
      if (d.x === -this.dx && d.y === -this.dy) continue;
      let nx = this.hx + d.x * this.CS * 2.2;
      let ny = this.hy + d.y * this.CS * 2.2;
      let wallClear = this.CS * 6;
      if (this.options.wrap) {
        nx = mod(nx, this.W);
        ny = mod(ny, this.H);
      } else {
        wallClear = Math.min(nx - edge, ny - edge, this.W - edge - nx, this.H - edge - ny);
        if (wallClear <= 0) continue;
        const px = nx + d.x * this.CS * 1.8;
        const py = ny + d.y * this.CS * 1.8;
        if (px < edge || py < edge || px > this.W - edge || py > this.H - edge) wallClear -= this.CS * 2.4;
      }
      const clearance = clearanceAt(nx, ny);
      const progress = foodDist - this.dist(nx, ny, this.food.x, this.food.y);
      const straightBonus = d.x === this.dx && d.y === this.dy ? this.CS * 0.55 : 0;
      const score =
        progress * 1.8 +
        straightBonus +
        Math.min(Math.max(clearance, -this.CS * 3), this.CS * 5) * 0.34 +
        Math.min(wallClear, this.CS * 5) * 0.22 +
        Math.random() * this.CS * 0.12;
      candidates.push({ d, score, clearance });
    }

    if (candidates.length === 0) return;
    const safe = candidates.filter((c) => c.clearance > this.R * 1.75 || c.d.x === this.dx && c.d.y === this.dy);
    const pool = safe.length > 0 ? safe : candidates;
    pool.sort((a, b) => b.score - a.score);
    this.turn(pool[0].d.x, pool[0].d.y);
  }

  private update(dt: number) {
    this.t += dt;
    const active = this.state === "playing" || this.state === "ready";

    if (active) {
      if (this.state === "ready") this.runAI(dt);
      if (this.state === "playing" || this.state === "ready") {
        this.advance(dt);
        if (this.state === "playing" || this.state === "ready") {
          this.buildBodyPoints();
          this.collide();
        }
      }
    }

    if (this.state === "playing") {
      if (this.comboT > 0) {
        this.comboT = Math.max(0, this.comboT - dt);
        if (this.comboT === 0 && this.combo > 1) this.combo = 1;
      }
    }

    this.updateFx(dt);
    this.shake = Math.max(0, this.shake - dt * 46);
    this.flash = Math.max(0, this.flash - dt * 2.6);
    this.newRecordFlash = Math.max(0, this.newRecordFlash - dt);
    this.emitHud(false);
  }

  private collide() {
    const head = this.headPos();
    const spacing = Math.max(1.6, this.R * 0.32);
    const neck = Math.max(7, Math.ceil((this.R * 2.3) / spacing));
    const rr = (this.R * 1.02) ** 2;
    for (let i = neck; i < this.bodyPts.length; i++) {
      if (this.dist2(head.x, head.y, this.bodyPts[i].x, this.bodyPts[i].y) < rr) {
        this.die();
        return;
      }
    }
    const foodRadius = this.food.kind === "golden" ? this.R * 1.25 : this.R * 1.1;
    if (this.dist2(head.x, head.y, this.food.x, this.food.y) < (this.R * 1.02 + foodRadius) ** 2) {
      this.eat();
    }
  }

  private eat() {
    const golden = this.food.kind === "golden";
    const playing = this.state === "playing";

    if (playing) {
      const withinCombo = this.comboT > 0;
      this.combo = withinCombo ? clamp(this.combo + 1, 1, 5) : 1;
      this.comboT = withinCombo ? Math.min(3.4, this.comboT + 1.15) : 2.9;
      const base = golden ? 30 : 10;
      const gained = base * this.combo;
      this.score += gained;
      this.apples += 1;
      this.speedMult = Math.min(2.4, this.speedMult + (golden ? 0.055 : 0.025));
      this.speed = this.baseSpeed * this.speedMult;
      this.bodyLen = Math.min(this.CS * 46, this.bodyLen + this.CS * (golden ? 2.1 : 1.65));
      if (this.score > this.best) {
        this.best = this.score;
        saveBest(this.best);
      }
      this.pops.push({
        x: this.food.x,
        y: this.food.y - this.R * 1.4,
        vy: -46,
        t: 1,
        text: `+${gained}${this.combo > 1 ? ` ×${this.combo}` : ""}`,
        rgb: golden ? "255,216,110" : "226,255,196",
        scale: golden ? 1.25 : 1,
      });
      this.soundEat(golden);
      if (navigator.vibrate) {
        try {
          navigator.vibrate(golden ? [18, 30, 22] : 16);
        } catch {
          /* noop */
        }
      }
    } else {
      this.bodyLen = Math.min(this.CS * 24, this.bodyLen + this.CS * 1.4);
    }

    const cfg = QUALITY[this.options.quality];
    const count = Math.round((golden ? 40 : 24) * cfg.particles);
    this.burst(this.food.x, this.food.y, count, golden ? 4 : 0, golden ? 90 : 70, golden ? 330 : 250);
    this.rings.push({
      x: this.food.x,
      y: this.food.y,
      t: 0,
      life: golden ? 0.9 : 0.7,
      rgb: golden ? "255,210,110" : "196,255,150",
      width: golden ? 4 : 3,
    });
    if (golden) {
      this.rings.push({ x: this.food.x, y: this.food.y, t: -0.16, life: 1, rgb: "255,242,190", width: 2 });
    }
    this.flash = golden ? 0.9 : 0.55;
    this.shake = Math.min(16, this.shake + (golden ? 11 : 6));
    this.foodIndex += 1;
    this.spawnFood();
    this.buildBodyPoints();
    this.emitHud(true);
  }

  private die() {
    if (this.state === "ready") {
      this.reset("ready");
      return;
    }
    if (this.state !== "playing") return;
    this.state = "dead";
    this.newRecord = this.score > this.bestAtStart && this.score > 0;
    if (this.newRecord) this.newRecordFlash = 1.4;
    if (this.score > this.best) {
      this.best = this.score;
      saveBest(this.best);
    }
    const head = this.headPos();
    const cfg = QUALITY[this.options.quality];
    this.burst(head.x, head.y, Math.round(48 * cfg.particles), 3, 110, 400);
    const stride = Math.max(3, Math.round(4 / Math.max(0.45, cfg.particles)));
    for (let i = 0; i < this.bodyPts.length; i += stride) {
      if (Math.random() > 0.45) continue;
      const p = this.bodyPts[i];
      this.burst(p.x, p.y, 2, 4, 30, 170, 0.42);
    }
    this.rings.push({ x: head.x, y: head.y, t: 0, life: 1.1, rgb: "255,116,104", width: 5 });
    this.rings.push({ x: head.x, y: head.y, t: -0.12, life: 0.9, rgb: "255,220,150", width: 2 });
    this.shake = 22;
    this.flash = 1;
    this.combo = 1;
    this.comboT = 0;
    this.soundDeath();
    if (navigator.vibrate) {
      try {
        navigator.vibrate([45, 55, 110]);
      } catch {
        /* noop */
      }
    }
    this.pops.push({
      x: head.x,
      y: head.y - this.R,
      vy: -34,
      t: 1.2,
      text: "SIGNAL LOST",
      rgb: "255,150,140",
      scale: 0.9,
    });
    this.emitHud(true);
  }

  /* ------------------------------------------------------------- effects */
  private burst(
    x: number,
    y: number,
    count: number,
    paletteOffset: number,
    speedMin: number,
    speedMax: number,
    sizeScale = 1
  ) {
    const cap = this.options.quality === "ultra" ? 200 : this.options.quality === "balanced" ? 150 : 90;
    for (let i = 0; i < count; i++) {
      if (this.particles.length >= cap) break;
      const angle = Math.random() * TAU;
      const speed = speedMin + Math.random() * (speedMax - speedMin);
      const life = 0.4 + Math.random() * 0.85;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life,
        max: life,
        size: (1.2 + Math.random() * 3.2) * sizeScale * (this.options.quality === "lite" ? 1.3 : 1),
        rgb: PARTICLE_RGB[(paletteOffset + Math.floor(Math.random() * 4)) % PARTICLE_RGB.length],
        gravity: 180 + Math.random() * 140,
      });
    }
  }

  private updateFx(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      const drag = Math.max(0, 1 - 2.3 * dt);
      p.vx *= drag;
      p.vy = p.vy * drag + p.gravity * dt;
      p.life -= dt;
      if (p.life <= 0) {
        this.particles[i] = this.particles[this.particles.length - 1];
        this.particles.pop();
      }
    }
    for (let i = this.rings.length - 1; i >= 0; i--) {
      const r = this.rings[i];
      r.t += dt;
      if (r.t > r.life) this.rings.splice(i, 1);
    }
    for (let i = this.pops.length - 1; i >= 0; i--) {
      const p = this.pops[i];
      p.y += p.vy * dt;
      p.vy *= 0.985;
      p.t -= dt * 1.1;
      if (p.t <= 0) this.pops.splice(i, 1);
    }
  }

  private spawnSparkle() {
    if (this.particles.length > 40) return;
    const around = this.food.kind === "golden" ? 2 : 1;
    for (let i = 0; i < around; i++) {
      const a = Math.random() * TAU;
      const d = this.R * (1.4 + Math.random() * 1.5);
      this.particles.push({
        x: this.food.x + Math.cos(a) * d,
        y: this.food.y + Math.sin(a) * d,
        vx: Math.cos(a) * 8,
        vy: -14 - Math.random() * 22,
        life: 0.7 + Math.random() * 0.7,
        max: 1.4,
        size: 1 + Math.random() * 1.8,
        rgb: this.food.kind === "golden" ? "255,238,170" : "220,255,190",
        gravity: -6,
      });
    }
  }

  private emitHud(force: boolean) {
    const now = performance.now();
    if (!force && now - this.lastHudAt < 95) return;
    this.lastHudAt = now;
    this.onHud({
      state: this.state,
      score: this.score,
      best: this.best,
      length: Math.max(1, Math.round(this.bodyLen / this.CS)),
      speed: this.speedMult,
      apples: this.apples,
      combo: this.combo,
      comboFrac: clamp(this.comboT / 3.4, 0, 1),
      fps: this.fps,
      wrap: this.options.wrap,
      newRecord: this.newRecord,
    });
  }

  private applyRenderScale(next: number) {
    this.renderScale = clamp(next, 0.62, 1);
    const cfg = QUALITY[this.options.quality];
    this.dpr = Math.max(0.6, Math.min(window.devicePixelRatio || 1, cfg.dpr) * this.renderScale);
    this.canvas.width = Math.round(this.W * this.dpr);
    this.canvas.height = Math.round(this.H * this.dpr);
    this.glows.clear();
    this.headCache = null;
    this.foodCache.clear();
    this.buildBackground();
    this.buildMotes();
  }

  /* ---------------------------------------------------------- background */
  private buildBackground() {
    const { W, H, CS } = this;
    const bg = document.createElement("canvas");
    bg.width = Math.round(W * this.dpr);
    bg.height = Math.round(H * this.dpr);
    const g = bg.getContext("2d");
    if (!g) return;
    g.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    const cfg = QUALITY[this.options.quality];
    const rng = makeRng(20260214);

    const base = g.createLinearGradient(0, 0, W, H);
    base.addColorStop(0, "#0b2118");
    base.addColorStop(0.4, "#071a13");
    base.addColorStop(0.75, "#05150f");
    base.addColorStop(1, "#020d09");
    g.fillStyle = base;
    g.fillRect(0, 0, W, H);

    // deep canopy glow
    const bloom = g.createRadialGradient(W * 0.4, H * 0.32, 10, W * 0.48, H * 0.46, Math.max(W, H) * 0.78);
    bloom.addColorStop(0, "rgba(76,164,108,0.26)");
    bloom.addColorStop(0.45, "rgba(22,82,56,0.16)");
    bloom.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = bloom;
    g.fillRect(0, 0, W, H);

    // warm light shaft from the upper-left
    const shaft = g.createLinearGradient(W * 0.05, 0, W * 0.62, H);
    shaft.addColorStop(0, "rgba(226,214,140,0.075)");
    shaft.addColorStop(0.35, "rgba(150,214,140,0.032)");
    shaft.addColorStop(1, "rgba(0,0,0,0)");
    g.save();
    g.globalCompositeOperation = "lighter";
    g.fillStyle = shaft;
    g.fillRect(0, 0, W, H);
    g.restore();

    // moss patches
    for (let i = 0; i < Math.round(9 * cfg.ambient) + 4; i++) {
      const x = rng() * W;
      const y = rng() * H;
      const rr = 40 + rng() * Math.min(W, H) * 0.22;
      const moss = g.createRadialGradient(x, y, 0, x, y, rr);
      const warm = rng() > 0.72;
      moss.addColorStop(0, warm ? "rgba(126,152,72,0.13)" : "rgba(54,142,86,0.15)");
      moss.addColorStop(0.6, warm ? "rgba(94,124,54,0.05)" : "rgba(32,102,62,0.06)");
      moss.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = moss;
      g.fillRect(x - rr, y - rr, rr * 2, rr * 2);
    }

    // subtle tactical grid
    const cell = Math.max(22, CS * 1.5);
    g.lineWidth = 1;
    g.strokeStyle = "rgba(148,255,196,0.035)";
    g.beginPath();
    for (let x = cell; x < W; x += cell) {
      g.moveTo(x, 0);
      g.lineTo(x, H);
    }
    for (let y = cell; y < H; y += cell) {
      g.moveTo(0, y);
      g.lineTo(W, y);
    }
    g.stroke();

    // major grid
    g.strokeStyle = "rgba(148,255,196,0.045)";
    g.beginPath();
    for (let x = cell * 5; x < W; x += cell * 5) {
      g.moveTo(x, 0);
      g.lineTo(x, H);
    }
    for (let y = cell * 5; y < H; y += cell * 5) {
      g.moveTo(0, y);
      g.lineTo(W, y);
    }
    g.stroke();

    // grass blades
    const blades = Math.round((W * H) / 2300 * cfg.ambient);
    g.lineCap = "round";
    for (let i = 0; i < blades; i++) {
      const x = rng() * W;
      const y = rng() * H;
      const len = 5 + rng() * 19;
      const bend = -0.9 + rng() * 0.7;
      const k = 0.16 + rng() * 0.7;
      const alpha = (0.1 + rng() * 0.22) * cfg.ambient;
      const gold = rng() > 0.82;
      g.strokeStyle = gold
        ? `rgba(${Math.round(150 + 70 * k)},${Math.round(160 + 60 * k)},${Math.round(90 + 40 * k)},${(alpha * 0.85).toFixed(3)})`
        : `rgba(${Math.round(44 + 96 * k)},${Math.round(124 + 96 * k)},${Math.round(70 + 64 * k)},${alpha.toFixed(3)})`;
      g.lineWidth = 0.8 + rng() * 1.5;
      g.beginPath();
      g.moveTo(x, y);
      g.quadraticCurveTo(x + Math.sin(bend) * len * 0.45, y - len * 0.6, x + Math.sin(bend) * len, y - len);
      g.stroke();
    }

    // fallen leaves
    const leaves = Math.round(8 * cfg.ambient) + 3;
    for (let i = 0; i < leaves; i++) {
      const x = 20 + rng() * (W - 40);
      const y = 20 + rng() * (H - 40);
      const len = 5 + rng() * 8;
      g.save();
      g.translate(x, y);
      g.rotate(rng() * TAU);
      g.fillStyle = rng() > 0.5 ? "rgba(154,158,76,0.16)" : "rgba(94,142,66,0.18)";
      g.beginPath();
      g.ellipse(0, 0, len, len * 0.42, 0, 0, TAU);
      g.fill();
      g.strokeStyle = "rgba(214,232,150,0.12)";
      g.lineWidth = 0.8;
      g.beginPath();
      g.moveTo(-len, 0);
      g.lineTo(len, 0);
      g.stroke();
      g.restore();
    }

    // stones
    const stones = Math.max(5, Math.round((W * H) / 82000 * cfg.ambient));
    for (let i = 0; i < stones; i++) {
      const x = 24 + rng() * (W - 48);
      const y = 24 + rng() * (H - 48);
      const r = 5 + rng() * 17;
      g.save();
      g.translate(x, y);
      g.rotate(rng() * TAU);
      g.fillStyle = "rgba(0,0,0,0.26)";
      g.beginPath();
      g.ellipse(r * 0.2, r * 0.32, r, r * 0.6, 0, 0, TAU);
      g.fill();
      const sg = g.createRadialGradient(-r * 0.4, -r * 0.45, r * 0.05, 0, 0, r * 1.05);
      sg.addColorStop(0, "rgba(122,142,128,0.7)");
      sg.addColorStop(0.55, "rgba(54,74,62,0.66)");
      sg.addColorStop(1, "rgba(16,30,24,0.7)");
      g.fillStyle = sg;
      g.beginPath();
      g.ellipse(0, 0, r, r * (0.55 + rng() * 0.24), 0, 0, TAU);
      g.fill();
      g.fillStyle = "rgba(88,158,104,0.16)";
      g.beginPath();
      g.ellipse(-r * 0.2, -r * 0.42, r * 0.56, r * 0.15, 0.2, 0, TAU);
      g.fill();
      g.restore();
    }

    // bioluminescent spores in the soil
    for (let i = 0; i < Math.round(26 * cfg.ambient); i++) {
      const x = rng() * W;
      const y = rng() * H;
      const r = 0.8 + rng() * 1.8;
      const warm = rng() > 0.78;
      const col = warm ? "255,222,150" : "160,255,190";
      const sg = g.createRadialGradient(x, y, 0, x, y, r * 4);
      sg.addColorStop(0, `rgba(${col},0.55)`);
      sg.addColorStop(0.35, `rgba(${col},0.16)`);
      sg.addColorStop(1, `rgba(${col},0)`);
      g.fillStyle = sg;
      g.fillRect(x - r * 4, y - r * 4, r * 8, r * 8);
    }

    // grass tufts at the arena edges
    g.lineCap = "round";
    for (let i = 0; i < Math.round(30 * cfg.ambient); i++) {
      const side = Math.floor(rng() * 4);
      const t = rng();
      const x = side === 0 ? 18 + rng() * 12 : side === 1 ? W - 18 - rng() * 12 : 18 + t * (W - 36);
      const y = side === 2 ? 18 + rng() * 12 : side === 3 ? H - 18 - rng() * 12 : 18 + t * (H - 36);
      const len = 8 + rng() * 16;
      g.strokeStyle = `rgba(126,192,120,${(0.14 + rng() * 0.16).toFixed(3)})`;
      g.lineWidth = 1.2;
      for (let b = 0; b < 3; b++) {
        const lean = (rng() - 0.5) * 10;
        g.beginPath();
        g.moveTo(x + b * 2 - 2, y);
        g.quadraticCurveTo(x + lean, y - len * 0.6, x + lean * 1.6, y - len);
        g.stroke();
      }
    }

    // edge shading + vignette
    const vg = g.createRadialGradient(W * 0.5, H * 0.48, Math.min(W, H) * 0.2, W * 0.5, H * 0.5, Math.max(W, H) * 0.75);
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(0.62, "rgba(0,8,5,0.18)");
    vg.addColorStop(1, "rgba(0,4,3,0.62)");
    g.fillStyle = vg;
    g.fillRect(0, 0, W, H);

    // arena frame
    const inset = 9;
    g.strokeStyle = "rgba(0,0,0,0.55)";
    g.lineWidth = 12;
    g.strokeRect(inset, inset, W - inset * 2, H - inset * 2);
    const frame = g.createLinearGradient(0, 0, W, H);
    frame.addColorStop(0, "rgba(190,255,170,0.5)");
    frame.addColorStop(0.35, "rgba(90,220,150,0.22)");
    frame.addColorStop(0.7, "rgba(110,255,190,0.3)");
    frame.addColorStop(1, "rgba(255,214,130,0.42)");
    g.strokeStyle = frame;
    g.lineWidth = 1.6;
    g.strokeRect(inset, inset, W - inset * 2, H - inset * 2);
    g.strokeStyle = "rgba(4,20,13,0.8)";
    g.lineWidth = 1;
    g.strokeRect(inset + 3, inset + 3, W - (inset + 3) * 2, H - (inset + 3) * 2);

    // corner brackets
    const L = Math.min(44, Math.min(W, H) * 0.085);
    g.strokeStyle = "rgba(206,255,210,0.7)";
    g.lineWidth = 2.6;
    g.lineCap = "round";
    const corners: Array<[number, number, number, number]> = [
      [inset + 1, inset + 1, 1, 1],
      [W - inset - 1, inset + 1, -1, 1],
      [inset + 1, H - inset - 1, 1, -1],
      [W - inset - 1, H - inset - 1, -1, -1],
    ];
    for (const [cx, cy, sx, sy] of corners) {
      g.beginPath();
      g.moveTo(cx + sx * L, cy);
      g.lineTo(cx, cy);
      g.lineTo(cx, cy + sy * L);
      g.stroke();
    }

    g.font = "600 9px 'JetBrains Mono', monospace";
    g.textAlign = "center";
    g.fillStyle = "rgba(190,255,205,0.35)";
    g.fillText(this.options.wrap ? "TORUS FIELD · WALLS OPEN" : "BIO FIELD · HARD WALLS", W / 2, inset + 21);

    this.bg = bg;
  }

  private buildMotes() {
    const cfg = QUALITY[this.options.quality];
    const count = Math.round(22 * cfg.ambient);
    const rng = makeRng(778899);
    this.motes = [];
    for (let i = 0; i < count; i++) {
      this.motes.push({
        x: 16 + rng() * Math.max(1, this.W - 32),
        y: 16 + rng() * Math.max(1, this.H - 32),
        r: 0.9 + rng() * 1.8,
        phase: rng() * TAU,
        speed: 0.25 + rng() * 0.6,
        drift: 8 + rng() * 22,
      });
    }
  }

  /* -------------------------------------------------------------- drawing */
  private glow(rgb: string, radius: number) {
    const r = Math.max(6, Math.round(radius));
    const key = `${rgb}|${r}|${this.dpr}`;
    const found = this.glows.get(key);
    if (found) return found;
    const px = Math.max(8, Math.ceil(r * 2 * this.dpr));
    const c = document.createElement("canvas");
    c.width = px;
    c.height = px;
    const g = c.getContext("2d");
    if (g) {
      const grd = g.createRadialGradient(px / 2, px / 2, 0, px / 2, px / 2, px / 2);
      grd.addColorStop(0, `rgba(${rgb},0.95)`);
      grd.addColorStop(0.32, `rgba(${rgb},0.42)`);
      grd.addColorStop(0.65, `rgba(${rgb},0.12)`);
      grd.addColorStop(1, `rgba(${rgb},0)`);
      g.fillStyle = grd;
      g.fillRect(0, 0, px, px);
    }
    this.glows.set(key, c);
    return c;
  }

  private drawGlow(x: number, y: number, radius: number, rgb: string, alpha: number) {
    if (alpha <= 0.003) return;
    const sprite = this.glow(rgb, radius);
    const { ctx } = this;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = alpha > 1 ? 1 : alpha;
    ctx.drawImage(sprite, x - radius, y - radius, radius * 2, radius * 2);
    ctx.restore();
  }

  private headSprite() {
    const key = `${this.R.toFixed(2)}|${this.dpr}`;
    if (this.headCache && this.headCache.key === key) return this.headCache;
    const R = this.R;
    const S = Math.ceil(R * 5.4);
    const px = Math.max(8, Math.ceil(S * this.dpr));
    const c = document.createElement("canvas");
    c.width = px;
    c.height = px;
    const g = c.getContext("2d");
    if (g) {
      g.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      g.translate(S / 2, S / 2);
      const rx = R * 1.82;
      const ry = R * 1.14;

      const body = g.createLinearGradient(-rx * 0.8, -ry, rx, ry);
      body.addColorStop(0, "#edffc0");
      body.addColorStop(0.32, "#c4fa88");
      body.addColorStop(0.7, "#7fdf74");
      body.addColorStop(1, "#3a9a5d");
      g.fillStyle = body;
      g.beginPath();
      g.ellipse(0, 0, rx, ry, 0, 0, TAU);
      g.fill();
      const rim = g.createLinearGradient(-rx, 0, rx, 0);
      rim.addColorStop(0, "rgba(5,42,27,0)");
      rim.addColorStop(0.55, "rgba(5,42,27,0)");
      rim.addColorStop(1, "rgba(5,42,27,0.5)");
      g.strokeStyle = rim;
      g.lineWidth = Math.max(1, R * 0.12);
      g.stroke();

      const top = g.createLinearGradient(0, -ry, 0, ry * 0.4);
      top.addColorStop(0, "rgba(255,255,225,0.55)");
      top.addColorStop(1, "rgba(255,255,225,0)");
      g.fillStyle = top;
      g.beginPath();
      g.ellipse(0, -ry * 0.42, rx * 0.8, ry * 0.34, -0.06, 0, TAU);
      g.fill();

      g.fillStyle = "rgba(214,255,164,0.46)";
      g.beginPath();
      g.ellipse(rx * 0.18, ry * 0.62, rx * 0.58, ry * 0.2, 0.03, 0, TAU);
      g.fill();

      for (const side of [-1, 1]) {
        const ex = rx * 0.36;
        const ey = side * ry * 0.47;
        const eyeR = R * 0.27;
        g.fillStyle = "rgba(8,40,24,0.22)";
        g.beginPath();
        g.ellipse(ex, ey + R * 0.045, eyeR * 1.08, eyeR * 1.08, 0, 0, TAU);
        g.fill();
        const eye = g.createRadialGradient(ex - eyeR * 0.25, ey - eyeR * 0.3, eyeR * 0.1, ex, ey, eyeR * 1.1);
        eye.addColorStop(0, "#ffffff");
        eye.addColorStop(0.62, "#f2ffe6");
        eye.addColorStop(1, "#c8e6b8");
        g.fillStyle = eye;
        g.beginPath();
        g.ellipse(ex, ey, eyeR, eyeR * 0.94, side * 0.2, 0, TAU);
        g.fill();

        const pupil = g.createRadialGradient(ex + eyeR * 0.32, ey - eyeR * 0.08, eyeR * 0.04, ex + eyeR * 0.24, ey, eyeR * 0.6);
        pupil.addColorStop(0, "#4f7c2e");
        pupil.addColorStop(0.5, "#1c3a17");
        pupil.addColorStop(1, "#050f07");
        g.fillStyle = pupil;
        g.beginPath();
        g.ellipse(ex + eyeR * 0.3, ey, eyeR * 0.42, eyeR * 0.72, side * -0.12, 0, TAU);
        g.fill();

        g.fillStyle = "rgba(255,255,255,0.96)";
        g.beginPath();
        g.arc(ex - eyeR * 0.26, ey - eyeR * 0.3, eyeR * 0.2, 0, TAU);
        g.fill();
        g.fillStyle = "rgba(255,255,255,0.6)";
        g.beginPath();
        g.arc(ex + eyeR * 0.5, ey + eyeR * 0.26, eyeR * 0.1, 0, TAU);
        g.fill();

        g.fillStyle = "rgba(6,42,26,0.42)";
        g.beginPath();
        g.ellipse(rx * 1.0, side * R * 0.2, R * 0.05, R * 0.035, 0, 0, TAU);
        g.fill();
      }

      g.strokeStyle = "rgba(8,52,31,0.5)";
      g.lineWidth = Math.max(1, R * 0.07);
      g.beginPath();
      g.moveTo(rx * 0.94, R * 0.02);
      g.quadraticCurveTo(rx * 0.62, ry * 0.46, rx * 0.16, ry * 0.4);
      g.stroke();
      g.strokeStyle = "rgba(255,255,220,0.45)";
      g.lineWidth = Math.max(0.8, R * 0.05);
      g.beginPath();
      g.moveTo(rx * 0.9, -R * 0.03);
      g.quadraticCurveTo(rx * 0.6, ry * 0.36, rx * 0.2, ry * 0.3);
      g.stroke();
      g.fillStyle = "rgba(255,150,150,0.16)";
      g.beginPath();
      g.ellipse(-rx * 0.18, ry * 0.5, rx * 0.32, ry * 0.22, 0.1, 0, TAU);
      g.fill();

      g.strokeStyle = "rgba(234,255,214,0.35)";
      g.lineWidth = Math.max(1, R * 0.07);
      g.beginPath();
      g.arc(0, 0, ry * 0.86, Math.PI * 0.72, Math.PI * 1.08);
      g.stroke();
    }
    this.headCache = { key, canvas: c, size: S };
    return this.headCache;
  }

  private appleSprite(kind: "apple" | "golden") {
    const key = `${this.R.toFixed(2)}|${this.dpr}|${kind}`;
    const cached = this.foodCache.get(key);
    if (cached) return cached;
    const R = this.R;
    const S = Math.ceil(R * 5.2);
    const px = Math.max(8, Math.ceil(S * this.dpr));
    const c = document.createElement("canvas");
    c.width = px;
    c.height = px;
    const g = c.getContext("2d");
    if (g) {
      g.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      g.translate(S / 2, S * 0.58);
      const r = R * 1.32;
      g.lineCap = "round";

      g.fillStyle = "rgba(0,0,0,0.3)";
      g.beginPath();
      g.ellipse(r * 0.16, r * 1.02, r * 0.92, r * 0.27, 0, 0, TAU);
      g.fill();

      if (kind === "golden") {
        const aura = g.createRadialGradient(0, 0, r * 0.2, 0, 0, r * 1.7);
        aura.addColorStop(0, "rgba(255,220,120,0.28)");
        aura.addColorStop(1, "rgba(255,220,120,0)");
        g.fillStyle = aura;
        g.fillRect(-r * 1.7, -r * 1.7, r * 3.4, r * 3.4);
      }

      const sg = g.createRadialGradient(-r * 0.34, -r * 0.42, r * 0.05, 0, 0, r * 1.16);
      if (kind === "golden") {
        sg.addColorStop(0, "#fff9d6");
        sg.addColorStop(0.28, "#ffe38a");
        sg.addColorStop(0.62, "#f4b62f");
        sg.addColorStop(0.88, "#b97412");
        sg.addColorStop(1, "#7c4708");
      } else {
        sg.addColorStop(0, "#ffc3a0");
        sg.addColorStop(0.26, "#ff6b5e");
        sg.addColorStop(0.6, "#e5333f");
        sg.addColorStop(0.86, "#a80f30");
        sg.addColorStop(1, "#6e0822");
      }
      g.fillStyle = sg;
      g.strokeStyle = kind === "golden" ? "rgba(92,54,6,0.6)" : "rgba(86,7,26,0.55)";
      g.lineWidth = Math.max(1, R * 0.08);
      g.beginPath();
      g.moveTo(0, -r * 0.86);
      g.bezierCurveTo(r * 0.78, -r * 1.2, r * 1.22, -r * 0.2, r * 0.86, r * 0.56);
      g.bezierCurveTo(r * 0.58, r * 1.1, -r * 0.58, r * 1.1, -r * 0.86, r * 0.56);
      g.bezierCurveTo(-r * 1.22, -r * 0.2, -r * 0.78, -r * 1.2, 0, -r * 0.86);
      g.closePath();
      g.fill();
      g.stroke();

      g.fillStyle = kind === "golden" ? "rgba(255,255,240,0.5)" : "rgba(255,238,228,0.38)";
      g.beginPath();
      g.ellipse(-r * 0.3, -r * 0.36, r * 0.3, r * 0.48, -0.65, 0, TAU);
      g.fill();
      g.fillStyle = "rgba(255,255,255,0.9)";
      g.beginPath();
      g.ellipse(-r * 0.41, -r * 0.46, r * 0.11, r * 0.22, -0.7, 0, TAU);
      g.fill();

      if (kind === "golden") {
        g.strokeStyle = "rgba(255,255,235,0.55)";
        g.lineWidth = Math.max(1, R * 0.07);
        for (let i = -1; i <= 1; i++) {
          g.beginPath();
          g.arc(0, 0, r * (0.5 + i * 0.18), -0.9, 0.9);
          g.stroke();
        }
      } else {
        g.fillStyle = "rgba(128,10,32,0.35)";
        g.beginPath();
        g.ellipse(r * 0.35, r * 0.5, r * 0.38, r * 0.18, 0.5, 0, TAU);
        g.fill();
      }

      g.strokeStyle = kind === "golden" ? "#6b4a10" : "#6b4021";
      g.lineWidth = Math.max(1.6, R * 0.16);
      g.beginPath();
      g.moveTo(0, -r * 0.84);
      g.quadraticCurveTo(r * 0.06, -r * 1.28, r * 0.26, -r * 1.48);
      g.stroke();

      const leaf = g.createLinearGradient(r * 0.2, -r * 1.5, r * 1, -r * 1.05);
      leaf.addColorStop(0, kind === "golden" ? "#ffe89b" : "#b6f27e");
      leaf.addColorStop(1, kind === "golden" ? "#9fba35" : "#2e8b4a");
      g.fillStyle = leaf;
      g.strokeStyle = "rgba(6,44,24,0.35)";
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(r * 0.26, -r * 1.38);
      g.bezierCurveTo(r * 0.7, -r * 1.86, r * 1.22, -r * 1.44, r * 0.94, -r * 0.98);
      g.bezierCurveTo(r * 0.62, -r * 0.88, r * 0.34, -r * 1.05, r * 0.26, -r * 1.38);
      g.closePath();
      g.fill();
      g.stroke();
      g.strokeStyle = "rgba(255,255,255,0.32)";
      g.beginPath();
      g.moveTo(r * 0.33, -r * 1.32);
      g.quadraticCurveTo(r * 0.68, -r * 1.4, r * 0.88, -r * 1.04);
      g.stroke();
    }
    const result = { canvas: c, size: S };
    this.foodCache.set(key, result);
    return result;
  }

  private drawApple(time: number) {
    const { ctx } = this;
    const golden = this.food.kind === "golden";
    const bob = Math.sin(time * 2.1) * this.R * 0.22;
    const pulse = 0.5 + 0.5 * Math.sin(time * 3.4);
    const y = this.food.y + bob;
    this.drawGlow(this.food.x, y, this.R * (golden ? 6.4 : 4.6), golden ? "255,206,96" : "255,116,92", golden ? 0.3 + pulse * 0.16 : 0.2 + pulse * 0.1);

    // halo ring
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.strokeStyle = golden ? "rgba(255,226,140,0.4)" : "rgba(255,168,140,0.28)";
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.ellipse(this.food.x, y + this.R * 0.9, this.R * (2 + pulse * 0.28), this.R * (0.52 + pulse * 0.1), 0, 0, TAU);
    ctx.stroke();
    ctx.restore();

    if (golden) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.translate(this.food.x, y);
      ctx.rotate(time * 0.7);
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * TAU;
        const dist = this.R * 2.15 + Math.sin(time * 2 + i) * this.R * 0.2;
        const x = Math.cos(a) * dist;
        const yy = Math.sin(a) * dist;
        const s = this.R * 0.34;
        ctx.fillStyle = "rgba(255,244,196,0.85)";
        ctx.beginPath();
        ctx.moveTo(x, yy - s);
        ctx.quadraticCurveTo(x + s * 0.16, yy - s * 0.16, x + s, yy);
        ctx.quadraticCurveTo(x + s * 0.16, yy + s * 0.16, x, yy + s);
        ctx.quadraticCurveTo(x - s * 0.16, yy + s * 0.16, x - s, yy);
        ctx.quadraticCurveTo(x - s * 0.16, yy - s * 0.16, x, yy - s);
        ctx.fill();
      }
      ctx.restore();
    }

    const sprite = this.appleSprite(this.food.kind);
    const scale = 1 + Math.sin(time * 4.2 + 1) * 0.035;
    ctx.save();
    ctx.translate(this.food.x, y);
    ctx.scale(scale, scale);
    ctx.drawImage(sprite.canvas, -sprite.size / 2, -sprite.size * 0.58, sprite.size, sprite.size);
    ctx.restore();
  }

  private drawBody() {
    const { ctx } = this;
    const base = this.bodyPts;
    const n = base.length;
    if (n < 2) return;
    const R = this.R;
    const quality = this.options.quality;

    // organic smoothing keeps the body from looking like a chain of discs
    const px = new Float32Array(n);
    const py = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      px[i] = base[i].x;
      py[i] = base[i].y;
    }
    if (quality !== "lite") {
      const passes = quality === "ultra" ? 2 : 1;
      for (let pass = 0; pass < passes; pass++) {
        for (let i = 1; i < n - 1; i++) {
          const lx = px[i - 1];
          const ly = py[i - 1];
          const rx = px[i + 1];
          const ry = py[i + 1];
          if (Math.abs(rx - lx) > this.W * 0.5 || Math.abs(ry - ly) > this.H * 0.5) continue;
          px[i] = px[i] * 0.5 + (lx + rx) * 0.25;
          py[i] = py[i] * 0.5 + (ly + ry) * 0.25;
        }
      }
    }

    const head = { x: px[0], y: py[0] };
    const tail = { x: px[n - 1], y: py[n - 1] };
    const angleAt = (i: number) => {
      const a = Math.max(0, i - 1);
      const b = Math.min(n - 1, i + 1);
      return Math.atan2(py[b] - py[a], px[b] - px[a]);
    };

    // body chunks: wide near the head, tapering toward the tail
    const chunks: Array<{ from: number; to: number; radius: number }> = [];
    const divisions = quality === "lite" ? 5 : quality === "ultra" ? 7 : 6;
    for (let k = 0; k < divisions; k++) {
      const from = Math.floor((k * (n - 1)) / divisions);
      const to = Math.min(n - 1, Math.floor(((k + 1) * (n - 1)) / divisions) + 1);
      const u = (k + 0.5) / divisions;
      const taper = Math.min(1, 0.16 + (u * divisions) / 1.6);
      chunks.push({ from, to, radius: R * (1.13 - 0.6 * u) * (0.36 + 0.64 * taper) + 0.4 });
    }

    const limit = this.options.wrap ? (Math.min(this.W, this.H) * 0.45) ** 2 : 1e18;
    const runs: Array<[number, number]> = [];
    let startI = 0;
    for (let i = 1; i < n; i++) {
      const dx = px[i] - px[i - 1];
      const dy = py[i] - py[i - 1];
      if (dx * dx + dy * dy > limit) {
        runs.push([startI, i - 1]);
        startI = i;
      }
    }
    runs.push([startI, n - 1]);

    const paint = (from: number, to: number, width: number, style: string | CanvasGradient, ox = 0, oy = 0) => {
      if (to - from < 1) return;
      ctx.strokeStyle = style;
      ctx.lineWidth = width;
      ctx.beginPath();
      ctx.moveTo(px[from] + ox, py[from] + oy);
      for (let i = from + 1; i <= to; i++) ctx.lineTo(px[i] + ox, py[i] + oy);
      ctx.stroke();
    };

    ctx.save();
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    // contact shadow
    for (const [from, to] of runs) {
      for (const chunk of chunks) {
        const a = Math.max(from, chunk.from);
        const b = Math.min(to, chunk.to);
        paint(a, b, chunk.radius * 2 + 5.5, "rgba(0,0,0,0.25)", 3.5, 6);
      }
    }

    // dark rim for silhouette
    for (const [from, to] of runs) {
      for (const chunk of chunks) {
        const a = Math.max(from, chunk.from);
        const b = Math.min(to, chunk.to);
        paint(a, b, chunk.radius * 2 + 2.2, "#0a2c1f");
      }
    }

    // body gradient (head-side fresh lime -> deep emerald tail)
    const bodyGrad = ctx.createLinearGradient(head.x, head.y, tail.x, tail.y);
    bodyGrad.addColorStop(0, "#dcffab");
    bodyGrad.addColorStop(0.18, "#b6f47f");
    bodyGrad.addColorStop(0.45, "#7cdd85");
    bodyGrad.addColorStop(0.7, "#43b97c");
    bodyGrad.addColorStop(0.9, "#258d6c");
    bodyGrad.addColorStop(1, "#166b52");
    for (const [from, to] of runs) {
      for (const chunk of chunks) {
        const a = Math.max(from, chunk.from);
        const b = Math.min(to, chunk.to);
        paint(a, b, chunk.radius * 2, bodyGrad);
      }
    }

    // cylindrical shading: dorsal light + ventral depth
    ctx.lineCap = "round";
    for (const [from, to] of runs) {
      for (const chunk of chunks) {
        const a = Math.max(from, chunk.from);
        const b = Math.min(to, chunk.to);
        if (b - a < 1) continue;
        paint(a, b, chunk.radius * 1.12, "rgba(244,255,214,0.16)", 0, -chunk.radius * 0.3);
        paint(a, b, chunk.radius * 0.86, "rgba(4,70,46,0.2)", 0, chunk.radius * 0.44);
      }
    }

    // dorsal diamond markings
    if (quality !== "lite") {
      const step = quality === "ultra" ? Math.max(3, Math.round(n / 46)) : Math.max(5, Math.round(n / 26));
      const marks = new Path2D();
      const glints = new Path2D();
      for (let i = 6; i < n - 3; i += step) {
        const u = i / (n - 1);
        if (u > 0.88) break;
        const r = Math.max(2, R * (1.08 - 0.66 * Math.pow(u, 0.6)));
        const a = angleAt(i);
        const nx = Math.sin(a);
        const ny = -Math.cos(a);
        const tx = Math.cos(a);
        const ty = Math.sin(a);
        const stagger = (i / step) % 2 < 1 ? -1 : 1;
        const cx = px[i] + nx * r * 0.18 + tx * stagger * r * 0.14;
        const cy = py[i] + ny * r * 0.18 + ty * stagger * r * 0.14;
        const len = r * 0.5;
        const wid = r * 0.27;
        marks.moveTo(cx + tx * len, cy + ty * len);
        marks.lineTo(cx + nx * wid, cy + ny * wid);
        marks.lineTo(cx - tx * len, cy - ty * len);
        marks.lineTo(cx - nx * wid, cy - ny * wid);
        marks.closePath();
        if (quality === "ultra") {
          const gx = cx + nx * r * 0.18;
          const gy = cy + ny * r * 0.18;
          glints.moveTo(gx + r * 0.15, gy);
          glints.arc(gx, gy, r * 0.15, 0, TAU);
        }
      }
      ctx.fillStyle = "rgba(10,78,56,0.2)";
      ctx.fill(marks);
      ctx.strokeStyle = "rgba(236,255,206,0.16)";
      ctx.lineWidth = 0.7;
      ctx.stroke(marks);
      if (quality === "ultra") {
        ctx.fillStyle = "rgba(250,255,234,0.17)";
        ctx.fill(glints);
      }
    }

    ctx.restore();
  }

  private drawHead(time: number) {
    const { ctx } = this;
    const head = this.headPos();
    const angle = Math.atan2(this.dy, this.dx);
    const sprite = this.headSprite();
    const R = this.R;
    const bob = Math.sin(time * 5.2) * 0.55;

    this.drawGlow(head.x, head.y, R * 3.3, "150,255,170", 0.13 + Math.sin(time * 3.2) * 0.035);

    ctx.save();
    ctx.fillStyle = "rgba(0,0,0,0.28)";
    ctx.beginPath();
    ctx.ellipse(head.x + 3, head.y + 5 + bob, R * 1.62, R * 1.08, 0, 0, TAU);
    ctx.fill();
    ctx.restore();

    ctx.save();
    ctx.translate(head.x, head.y + bob);
    ctx.rotate(angle);
    ctx.drawImage(sprite.canvas, -sprite.size / 2, -sprite.size / 2, sprite.size, sprite.size);

    const blink = (time % 4.4) > 4.22;
    if (!blink) {
      // eye glints already baked; subtle animated catch light
      ctx.globalCompositeOperation = "lighter";
      ctx.fillStyle = "rgba(255,255,255,0.6)";
      for (const side of [-1, 1]) {
        ctx.beginPath();
        ctx.arc(R * 0.34 - R * 0.06, side * R * 0.76 - R * 0.1, R * 0.05, 0, TAU);
        ctx.fill();
      }
      ctx.globalCompositeOperation = "source-over";
    } else {
      for (const side of [-1, 1]) {
        ctx.fillStyle = "#8ee07a";
        ctx.beginPath();
        ctx.ellipse(R * 0.46, side * R * 0.67, R * 0.38, R * 0.33, side * 0.22, 0, TAU);
        ctx.fill();
        ctx.strokeStyle = "rgba(20,66,40,0.6)";
        ctx.lineWidth = Math.max(1, R * 0.07);
        ctx.beginPath();
        ctx.arc(R * 0.46, side * R * 0.67, R * 0.31, Math.PI * 1.12, Math.PI * 1.88);
        ctx.stroke();
      }
    }

    if (Math.sin(time * 5.6) > 0.72) {
      const ext = R * (1.1 + Math.abs(Math.sin(time * 8)) * 0.55);
      ctx.strokeStyle = "#ff6f96";
      ctx.lineWidth = Math.max(1.4, R * 0.11);
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(R * 1.68, 0);
      ctx.lineTo(R * 1.68 + ext * 0.55, 0);
      ctx.moveTo(R * 1.68 + ext * 0.55, 0);
      ctx.lineTo(R * 1.68 + ext, -R * 0.2);
      ctx.moveTo(R * 1.68 + ext * 0.55, 0);
      ctx.lineTo(R * 1.68 + ext, R * 0.2);
      ctx.stroke();
    }
    ctx.restore();
  }

  private drawParticles() {
    if (this.particles.length === 0) return;
    const { ctx } = this;
    const buckets = new Map<string, Path2D>();
    for (const p of this.particles) {
      const a = clamp(p.life / p.max, 0, 1);
      const band = a > 0.75 ? 3 : a > 0.5 ? 2 : a > 0.25 ? 1 : 0;
      const key = `${p.rgb}|${band}`;
      let path = buckets.get(key);
      if (!path) {
        path = new Path2D();
        buckets.set(key, path);
      }
      const r = p.size * (0.35 + a * 0.85);
      path.moveTo(p.x + r, p.y);
      path.arc(p.x, p.y, r, 0, TAU);
    }
    const alphas = [0.2, 0.46, 0.74, 1];
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const [key, path] of buckets) {
      const sep = key.lastIndexOf("|");
      const rgb = key.slice(0, sep);
      const band = Number(key.slice(sep + 1));
      ctx.globalAlpha = alphas[band];
      ctx.fillStyle = `rgb(${rgb})`;
      ctx.fill(path);
    }
    ctx.restore();
  }

  private drawRings() {
    const { ctx } = this;
    for (const ring of this.rings) {
      if (ring.t < 0) continue;
      const k = clamp(ring.t / ring.life, 0, 1);
      const radius = this.R * (1.4 + k * 5.6);
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = (1 - k) * 0.65;
      ctx.strokeStyle = `rgb(${ring.rgb})`;
      ctx.lineWidth = Math.max(0.6, ring.width * (1 - k));
      ctx.beginPath();
      ctx.arc(ring.x, ring.y, radius, 0, TAU);
      ctx.stroke();
      ctx.restore();
    }
  }

  private drawPops() {
    const { ctx } = this;
    if (this.pops.length === 0) return;
    ctx.save();
    ctx.textAlign = "center";
    for (const pop of this.pops) {
      const alpha = clamp(pop.t, 0, 1);
      const size = Math.max(11, this.R * 1.05 * pop.scale);
      ctx.font = `800 ${size}px Unbounded, Manrope, sans-serif`;
      ctx.globalAlpha = alpha;
      ctx.fillStyle = "rgba(4,22,14,0.55)";
      ctx.fillText(pop.text, pop.x + 1.5, pop.y + 2.5);
      ctx.fillStyle = `rgb(${pop.rgb})`;
      ctx.shadowColor = `rgba(${pop.rgb},0.8)`;
      ctx.shadowBlur = 12;
      ctx.fillText(pop.text, pop.x, pop.y);
      ctx.shadowBlur = 0;
    }
    ctx.restore();
  }

  private drawMotes(time: number) {
    const { ctx } = this;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const m of this.motes) {
      const x = m.x + Math.sin(time * m.speed + m.phase) * m.drift;
      const y = m.y + Math.cos(time * m.speed * 0.7 + m.phase) * m.drift * 0.6;
      const a = 0.28 + 0.32 * (0.5 + 0.5 * Math.sin(time * 1.6 + m.phase));
      ctx.fillStyle = `rgba(206,255,206,${a * 0.1})`;
      ctx.beginPath();
      ctx.arc(x, y, m.r * 2.3, 0, TAU);
      ctx.fill();
      ctx.fillStyle = `rgba(226,255,214,${a})`;
      ctx.beginPath();
      ctx.arc(x, y, m.r * 0.62, 0, TAU);
      ctx.fill();
    }
    ctx.restore();
  }

  private drawEdgeDanger() {
    if (this.options.wrap) return;
    const { ctx, W, H } = this;
    const zones: Array<{ alpha: number; grad: CanvasGradient }> = [];
    const reach = this.R * 6;
    const nearLeft = 1 - clamp(this.hx / reach, 0, 1);
    const nearRight = 1 - clamp((W - this.hx) / reach, 0, 1);
    const nearTop = 1 - clamp(this.hy / reach, 0, 1);
    const nearBottom = 1 - clamp((H - this.hy) / reach, 0, 1);

    if (nearLeft > 0.1) {
      const grad = ctx.createLinearGradient(0, 0, reach, 0);
      grad.addColorStop(0, "rgba(255,96,82,0.55)");
      grad.addColorStop(1, "rgba(255,96,82,0)");
      zones.push({ alpha: nearLeft * 0.5, grad });
    }
    if (nearRight > 0.1) {
      const grad = ctx.createLinearGradient(W, 0, W - reach, 0);
      grad.addColorStop(0, "rgba(255,96,82,0.55)");
      grad.addColorStop(1, "rgba(255,96,82,0)");
      zones.push({ alpha: nearRight * 0.5, grad });
    }
    if (nearTop > 0.1) {
      const grad = ctx.createLinearGradient(0, 0, 0, reach);
      grad.addColorStop(0, "rgba(255,96,82,0.55)");
      grad.addColorStop(1, "rgba(255,96,82,0)");
      zones.push({ alpha: nearTop * 0.5, grad });
    }
    if (nearBottom > 0.1) {
      const grad = ctx.createLinearGradient(0, H, 0, H - reach);
      grad.addColorStop(0, "rgba(255,96,82,0.55)");
      grad.addColorStop(1, "rgba(255,96,82,0)");
      zones.push({ alpha: nearBottom * 0.5, grad });
    }
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const z of zones) {
      ctx.globalAlpha = z.alpha;
      ctx.fillStyle = z.grad;
      ctx.fillRect(0, 0, W, H);
    }
    ctx.restore();
  }

  private draw(time: number) {
    const { ctx, W, H } = this;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    if (this.bg) ctx.drawImage(this.bg, 0, 0, this.canvas.width, this.canvas.height);
    else {
      ctx.fillStyle = "#051310";
      ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    }
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.save();

    if (this.shake > 0.35) {
      ctx.translate((Math.random() - 0.5) * this.shake, (Math.random() - 0.5) * this.shake);
    }

    this.drawMotes(time);
    this.drawEdgeDanger();

    if (this.state !== "dead") {
      if (Math.random() < 0.028) this.spawnSparkle();
    }
    this.drawApple(time);
    this.drawRings();
    this.drawBody();
    if (this.state !== "dead") this.drawHead(time);
    this.drawParticles();
    this.drawPops();

    // wrap field animated border
    if (this.options.wrap) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.strokeStyle = "rgba(136,255,190,0.3)";
      ctx.lineWidth = 1.4;
      ctx.setLineDash([11, 9]);
      ctx.lineDashOffset = -time * 26;
      ctx.strokeRect(9.5, 9.5, W - 19, H - 19);
      ctx.restore();
    }

    if (this.flash > 0.01) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.fillStyle = this.state === "dead" ? `rgba(255,88,76,${this.flash * 0.16})` : `rgba(255,234,170,${this.flash * 0.12})`;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }

    ctx.restore();
  }

  /* ---------------------------------------------------------------- loop */
  private tick = (now: number) => {
    if (this.destroyed) return;
    this.raf = requestAnimationFrame(this.tick);
    const raw = (now - this.lastFrame) / 1000;
    this.lastFrame = now;
    const dt = clamp(raw, 0.0005, 0.05);
    this.fpsAcc += raw;
    this.fpsFrames += 1;
    if (this.fpsAcc >= 0.45) {
      this.fps = clamp(Math.round(this.fpsFrames / this.fpsAcc), 1, 240);
      const nowMs = now;
      if (this.fpsAcc > 0 && nowMs - this.lastScaleShift > 4200) {
        if (this.fps < 42 && this.renderScale > 0.63) {
          this.applyRenderScale(this.renderScale - 0.12);
          this.lastScaleShift = nowMs;
        } else if (this.fps > 57 && this.renderScale < 0.99) {
          this.applyRenderScale(this.renderScale + 0.08);
          this.lastScaleShift = nowMs;
        }
      }
      this.fpsAcc = 0;
      this.fpsFrames = 0;
    }
    this.update(dt);
    this.draw(this.t);
  };
}
