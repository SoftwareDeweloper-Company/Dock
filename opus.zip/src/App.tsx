import { useEffect, useState } from "react";
import {
  Activity,
  Apple,
  Gauge,
  Keyboard,
  Maximize2,
  Minimize2,
  MousePointer2,
  Orbit,
  Ruler,
  Shield,
  SlidersHorizontal,
  Sparkles,
  Trophy,
  Volume2,
  VolumeX,
} from "lucide-react";
import { cn } from "@/utils/cn";
import { GameStage } from "@/components/GameStage";
import { Keycap, MiniMeter, Segmented, Toggle } from "@/components/ui";
import {
  loadBest,
  loadOptions,
  saveOptions,
  type EngineOptions,
  type HudSnapshot,
  type Quality,
} from "@/game/engine";

const INITIAL_HUD: HudSnapshot = {
  state: "ready",
  score: 0,
  best: loadBest(),
  length: 6,
  speed: 1,
  apples: 0,
  combo: 1,
  comboFrac: 0,
  fps: 60,
  wrap: false,
  newRecord: false,
};

const QUALITY_COPY: Record<Quality, string> = {
  ultra: "2× DPR · чешуя, мультислойное свечение и полный набор частиц",
  balanced: "1.5× DPR · свечение и текстуры при стабильном FPS",
  lite: "1× DPR · упрощённые эффекты для слабых устройств",
};

function LogoMark() {
  return (
    <div className="relative grid h-11 w-11 flex-none place-items-center overflow-hidden rounded-[14px] border border-neon/25 bg-[radial-gradient(circle_at_28%_18%,rgba(199,255,150,0.28),rgba(7,24,16,0.96))] shadow-[0_10px_26px_-14px_rgba(0,0,0,0.9),inset_0_1px_0_rgba(255,255,255,0.14)]">
      <div className="absolute inset-0 bg-[linear-gradient(150deg,transparent_35%,rgba(189,245,109,0.12))]" />
      <svg viewBox="0 0 32 32" className="relative h-7 w-7" aria-hidden>
        <defs>
          <linearGradient id="brandSnake" x1="4" y1="6" x2="28" y2="27" gradientUnits="userSpaceOnUse">
            <stop stopColor="#eaffc2" />
            <stop offset="0.45" stopColor="#a9f47a" />
            <stop offset="1" stopColor="#34c98a" />
          </linearGradient>
        </defs>
        <path
          d="M9.5 22.4c0-3.4 2.8-5.6 6.3-5.6h1.9c2.6 0 4.5-1.7 4.5-3.9 0-2.3-1.9-4-4.5-4H13"
          fill="none"
          stroke="url(#brandSnake)"
          strokeWidth="4"
          strokeLinecap="round"
        />
        <circle cx="21.9" cy="20.2" r="2.1" fill="url(#brandSnake)" />
        <circle cx="22.4" cy="19.6" r="0.62" fill="#09220f" />
        <circle cx="22.9" cy="20.9" r="0.34" fill="rgba(255,255,255,0.85)" />
        <circle cx="11.3" cy="10.2" r="1.2" fill="#ffd479" />
      </svg>
    </div>
  );
}

function ControlRow({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="min-w-0">
        <div className="text-[11.5px] font-semibold text-ink/85">{label}</div>
        {hint ? <div className="mono mt-0.5 text-[8px] uppercase tracking-[0.14em] text-fog/45">{hint}</div> : null}
      </div>
      <div className="flex flex-none gap-1">{children}</div>
    </div>
  );
}

function Header({
  best,
  options,
  fullscreen,
  onToggleSound,
  onToggleFullscreen,
}: {
  best: number;
  options: EngineOptions;
  fullscreen: boolean;
  onToggleSound: () => void;
  onToggleFullscreen: () => void;
}) {
  return (
    <header className="flex items-center justify-between gap-3 py-4 sm:py-5">
      <div className="flex min-w-0 items-center gap-3">
        <LogoMark />
        <div className="min-w-0">
          <div className="flex items-baseline gap-1.5">
            <span className="font-display text-[15px] font-extrabold leading-none tracking-[0.14em] text-ink sm:text-[17px]">
              HYPER
            </span>
            <span className="font-display text-[15px] font-extrabold leading-none tracking-[0.14em] text-neon sm:text-[17px]">
              SNAKE
            </span>
            <span className="badge ml-1 hidden !py-1 !text-[7.5px] sm:inline-flex">V2.0</span>
          </div>
          <div className="mono mt-1.5 flex items-center gap-1.5 text-[7.5px] uppercase tracking-[0.26em] text-fog/55 sm:text-[8px]">
            <span className="hidden sm:inline">BIO ARCADE</span>
            <span className="hidden h-2 w-px bg-fog/25 sm:inline" />
            <span>TERMUX EDITION</span>
          </div>
        </div>
      </div>

      <div className="flex flex-none items-center gap-1.5 sm:gap-2">
        <div className="hidden items-center gap-2 rounded-xl border border-line/70 bg-shell/50 px-3 py-1.5 md:flex">
          <Trophy size={12} className="text-amber" />
          <span className="mono text-[8px] font-semibold uppercase tracking-[0.16em] text-fog/55">Рекорд</span>
          <span className="num text-[13px] font-bold text-amber">{best.toLocaleString("ru-RU")}</span>
        </div>
        <button
          type="button"
          onClick={onToggleSound}
          className="icon-btn"
          data-active={options.sound ? "true" : "false"}
          aria-label={options.sound ? "Выключить звук" : "Включить звук"}
          aria-pressed={options.sound}
          title={options.sound ? "Звук включён" : "Звук выключен"}
        >
          {options.sound ? <Volume2 size={15} /> : <VolumeX size={15} />}
        </button>
        <button
          type="button"
          onClick={onToggleFullscreen}
          className="icon-btn"
          aria-label={fullscreen ? "Выйти из полноэкранного режима" : "Полноэкранный режим"}
          title={fullscreen ? "Выйти из полноэкранного режима" : "На весь экран"}
        >
          {fullscreen ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
        </button>
        <div className="badge badge-live hidden !px-2.5 !py-1.5 lg:inline-flex">
          <span className="dot-live" />
          SYSTEM ONLINE
        </div>
      </div>
    </header>
  );
}

function Intro({ wrap }: { wrap: boolean }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4">
      <div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="badge badge-live">
            <span className="dot-live" /> СЕЗОН 02
          </span>
          <span className="mono text-[8px] uppercase tracking-[0.24em] text-fog/40">/ NIGHT RUN</span>
          <span className="mono hidden text-[8px] uppercase tracking-[0.18em] text-fog/40 sm:inline">
            · {wrap ? "TORUS FIELD" : "HARD WALLS"}
          </span>
        </div>
        <h1 className="mt-2 font-display text-[17px] font-bold leading-tight tracking-tight text-ink/95 sm:text-[22px]">
          Съедай. Расти.<br className="sm:hidden" /> <span className="text-neon">Не&nbsp;останавливайся.</span>
        </h1>
      </div>
      <div className="hidden flex-none items-center gap-2 md:flex">
        <span className="badge">
          <Sparkles size={9} className="text-amber" /> GLOW ENGINE
        </span>
        <span className="badge">
          <Activity size={9} className="text-mint" /> {`${60} FPS TARGET`}
        </span>
      </div>
    </div>
  );
}

function TelemetryCard({ hud }: { hud: HudSnapshot }) {
  const progress = hud.best > 0 ? Math.min(100, (hud.score / hud.best) * 100) : 0;
  const remaining = Math.max(0, hud.best - hud.score);
  return (
    <section className="surface overflow-hidden">
      <div className="surface-head">
        <Activity size={13} className="text-mint" />
        <span className="label">Телеметрия</span>
        <span className="badge badge-live ml-auto !py-1 !text-[7px]">
          <span className="dot-live" /> LIVE
        </span>
      </div>

      <div className="relative px-5 pb-5 pt-2.5">
        <div className="flex items-end justify-between gap-3">
          <div>
            <div className="eyebrow">Текущий счёт</div>
            <div key={hud.score} className="num anim-pop mt-1 text-[42px] font-extrabold leading-none text-ink">
              {hud.score.toLocaleString("ru-RU")}
            </div>
          </div>
          <div className="pb-0.5 text-right">
            <div className="label">Рекорд</div>
            <div className="mt-1 flex items-center justify-end gap-1.5">
              <Trophy size={12} className="text-amber" />
              <span className="num text-[19px] font-bold leading-none text-amber">
                {hud.best.toLocaleString("ru-RU")}
              </span>
            </div>
          </div>
        </div>

        <div className="mt-4">
          <div className="mb-1.5 flex items-center justify-between">
            <span className="label">Комбо</span>
            <span className={cn("mono text-[10px] font-bold", hud.combo > 1 ? "text-amber" : "text-fog/45")}>
              ×{hud.combo}
            </span>
          </div>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((step) => (
              <span
                key={step}
                className={cn(
                  "h-1.5 flex-1 rounded-full border transition-all duration-300",
                  hud.combo >= step
                    ? "border-amber/50 bg-gradient-to-r from-amber to-neon shadow-[0_0_10px_rgba(255,212,121,0.4)]"
                    : "border-line/60 bg-line/25"
                )}
              />
            ))}
          </div>
        </div>

        <div className="mt-4 grid grid-cols-3 gap-1.5">
          {[
            { icon: <Ruler size={11} />, label: "Длина", value: hud.length, tone: "text-ice" },
            { icon: <Apple size={11} />, label: "Яблоки", value: hud.apples, tone: "text-coral" },
            { icon: <Gauge size={11} />, label: "Скорость", value: `${hud.speed.toFixed(1)}×`, tone: "text-mint" },
          ].map((stat) => (
            <div key={stat.label} className="rounded-xl border border-line/60 bg-shell/45 px-2.5 py-2">
              <div className="flex items-center gap-1 text-fog/50">{stat.icon}</div>
              <div className={cn("num mt-1 text-[15px] font-bold leading-none", stat.tone)}>{stat.value}</div>
              <div className="mono mt-1 text-[7.5px] uppercase tracking-[0.14em] text-fog/50">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="mt-4">
          <div className="mb-1.5 flex items-center justify-between">
            <span className="label">До рекорда</span>
            <span className="mono text-[9px] font-semibold text-fog/60">
              {hud.best === 0 ? "ПЕРВЫЙ РЕКОРД" : remaining === 0 ? "МАКСИМУМ" : `${remaining} ОЧК.`}
            </span>
          </div>
          <MiniMeter value={remaining === 0 && hud.score > 0 ? 100 : progress} tone="amber" />
        </div>

        <div className="mt-4 flex items-center justify-between rounded-xl border border-line/60 bg-shell/40 px-3 py-2">
          <span className="mono flex items-center gap-1.5 text-[8px] uppercase tracking-[0.14em] text-fog/50">
            {hud.wrap ? <Orbit size={10} className="text-mint" /> : <Shield size={10} className="text-fog/60" />}
            {hud.wrap ? "Торус-поле" : "Жёсткие стены"}
          </span>
          <span className={cn("mono text-[9px] font-semibold", hud.fps >= 54 ? "text-mint" : hud.fps >= 38 ? "text-amber" : "text-coral")}>
            {hud.fps} FPS
          </span>
        </div>
      </div>
    </section>
  );
}

function SettingsCard({
  options,
  onChange,
}: {
  options: EngineOptions;
  onChange: (next: EngineOptions) => void;
}) {
  return (
    <section className="surface overflow-hidden">
      <div className="surface-head">
        <SlidersHorizontal size={13} className="text-mint" />
        <span className="label">Настройки</span>
        <span className="badge ml-auto !py-1 !text-[7px]">LIVE SYNC</span>
      </div>

      <div className="relative px-4 pb-4 pt-2">
        <div className="space-y-1">
          <Toggle
            checked={options.sound}
            onChange={(value) => onChange({ ...options, sound: value })}
            label="Звук"
            description="Синтезированные сигналы и вибрация"
            icon={options.sound ? <Volume2 size={14} /> : <VolumeX size={14} />}
          />
          <div className="mx-1 h-px bg-line/50" />
          <Toggle
            checked={options.wrap}
            onChange={(value) => onChange({ ...options, wrap: value })}
            label="Стены насквозь"
            description="Торус-режим: вылетай с другой стороны"
            icon={<Orbit size={14} />}
          />
        </div>

        <div className="mt-3 border-t border-line/50 pt-3">
          <div className="mb-2 flex items-center justify-between">
            <span className="label">Качество рендера</span>
            <span className="mono text-[7.5px] uppercase tracking-[0.14em] text-fog/40">GPU · 2D</span>
          </div>
          <Segmented<Quality>
            value={options.quality}
            onChange={(quality) => onChange({ ...options, quality })}
            ariaLabel="Качество рендера"
            options={[
              { value: "ultra", label: "Ультра" },
              { value: "balanced", label: "Баланс" },
              { value: "lite", label: "Лайт" },
            ]}
          />
          <p className="mt-2 text-[9.5px] leading-relaxed text-fog/50">{QUALITY_COPY[options.quality]}</p>
        </div>
      </div>
    </section>
  );
}

function ControlsCard({ wide = false }: { wide?: boolean }) {
  const rows = [
    {
      label: "Поворот",
      hint: "СТРЕЛКИ ИЛИ WASD",
      keys: (
        <>
          <Keycap>↑</Keycap>
          <Keycap>↓</Keycap>
          <Keycap>←</Keycap>
          <Keycap>→</Keycap>
        </>
      ),
    },
    {
      label: "Пауза",
      hint: "ИЛИ ESC",
      keys: <Keycap wide>SPACE</Keycap>,
    },
    {
      label: "Новый забег",
      hint: "В ЛЮБОЙ МОМЕНТ",
      keys: <Keycap>R</Keycap>,
    },
  ];

  return (
    <section className="surface overflow-hidden">
      <div className="surface-head !py-0 !pb-0 !pt-3.5">
        <Keyboard size={13} className="text-mint" />
        <span className="label">Управление</span>
        <span className="badge ml-auto !py-1 !text-[7px]">KEYBOARD</span>
      </div>

      <div
        className={cn(
          "relative gap-2 px-4 pb-3.5 pt-3",
          wide ? "grid sm:grid-cols-3" : "space-y-2.5"
        )}
      >
        {rows.map((row) => (
          <div key={row.label} className={cn(wide && "rounded-xl border border-line/40 bg-shell/30 px-3 py-2")}>
            <ControlRow label={row.label} hint={row.hint}>
              {row.keys}
            </ControlRow>
          </div>
        ))}

        {!wide ? (
          <div className="mt-3 flex gap-2 rounded-xl border border-line/60 bg-shell/40 px-3 py-2.5">
            <MousePointer2 size={13} className="mt-0.5 flex-none text-mint/80" />
            <p className="text-[9.5px] leading-relaxed text-fog/60">
              Свайпай по арене на телефоне. На десктопе можно кликать в сторону поворота — змейка
              поймёт направление.
            </p>
          </div>
        ) : (
          <div className="flex items-start gap-2 rounded-xl border border-line/40 bg-shell/30 px-3 py-2 sm:col-span-3">
            <MousePointer2 size={12} className="mt-0.5 flex-none text-mint/80" />
            <p className="text-[9.5px] leading-relaxed text-fog/55">
              Свайп на телефоне, клик или стрелки на десктопе. После гибели забег начинается заново одним нажатием.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

export default function App() {
  const [options, setOptions] = useState<EngineOptions>(() => loadOptions());
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [fullscreen, setFullscreen] = useState(false);

  useEffect(() => {
    saveOptions(options);
  }, [options]);

  useEffect(() => {
    const onFullscreen = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onFullscreen);
    return () => document.removeEventListener("fullscreenchange", onFullscreen);
  }, []);

  const toggleFullscreen = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    } catch {
      /* fullscreen is not available on every platform */
    }
  };

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      <div className="app-bg" aria-hidden>
        <div className="orb orb-amber" />
        <div className="orb orb-mint" />
      </div>
      <div className="grid-veil" aria-hidden />

      <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-[1560px] flex-col px-3 sm:px-5 lg:px-8">
        <Header
          best={hud.best}
          options={options}
          fullscreen={fullscreen}
          onToggleSound={() => setOptions((prev) => ({ ...prev, sound: !prev.sound }))}
          onToggleFullscreen={toggleFullscreen}
        />

        <Intro wrap={options.wrap} />

        <main className="flex-1 pb-7">
          <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_352px] xl:gap-5">
            <div className="min-w-0">
              <GameStage options={options} hud={hud} onHud={setHud} />

              <div className="mt-4">
                <ControlsCard wide />
              </div>
            </div>

            <aside className="grid gap-4 sm:grid-cols-2 xl:grid-cols-1">
              <TelemetryCard hud={hud} />
              <SettingsCard options={options} onChange={setOptions} />
            </aside>
          </div>
        </main>

        <footer className="relative flex flex-col gap-2 border-t border-line/40 py-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2.5">
            <span className="font-display text-[9px] font-bold tracking-[0.24em] text-fog/45">HYPER SNAKE</span>
            <span className="h-2.5 w-px bg-line" />
            <span className="mono text-[8px] uppercase tracking-[0.16em] text-fog/35">
              One-file arcade · remastered for web
            </span>
          </div>
          <div className="mono flex flex-wrap items-center gap-x-3 gap-y-1 text-[8px] uppercase tracking-[0.14em] text-fog/35">
            <span>Canvas 2D</span>
            <span className="text-line">·</span>
            <span>Procedural audio</span>
            <span className="text-line">·</span>
            <span>Сохраняется на устройстве</span>
          </div>
        </footer>
      </div>
    </div>
  );
}
