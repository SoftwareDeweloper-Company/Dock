import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/utils/cn";

export function IconButton({
  label,
  active,
  className,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  label: string;
  active?: boolean;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      className={cn("icon-btn", className)}
      aria-label={label}
      title={label}
      data-active={active ? "true" : "false"}
      {...props}
    >
      {children}
    </button>
  );
}

export function Keycap({ children, wide }: { children: ReactNode; wide?: boolean }) {
  return <span className={cn("key", wide && "min-w-[54px]")}>{children}</span>;
}

export function Toggle({
  checked,
  onChange,
  label,
  description,
  icon,
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
  description: string;
  icon?: ReactNode;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className="group flex w-full items-center gap-3 rounded-xl px-1 py-1.5 text-left transition-colors hover:bg-white/[0.025]"
    >
      {icon ? (
        <span
          className={cn(
            "grid h-8 w-8 flex-none place-items-center rounded-lg border transition-colors",
            checked
              ? "border-neon/30 bg-neon/10 text-neon"
              : "border-line/80 bg-shell/60 text-fog/70"
          )}
        >
          {icon}
        </span>
      ) : null}
      <span className="min-w-0 flex-1">
        <span className="block text-[12px] font-semibold tracking-tight text-ink/90">{label}</span>
        <span className="mt-0.5 block text-[10px] leading-snug text-fog/65">{description}</span>
      </span>
      <span className="switch" data-on={checked ? "true" : "false"} aria-hidden>
        <span />
      </span>
    </button>
  );
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
  ariaLabel,
}: {
  value: T;
  options: Array<{ value: T; label: string }>;
  onChange: (value: T) => void;
  ariaLabel: string;
}) {
  return (
    <div className="seg" role="group" aria-label={ariaLabel}>
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          data-active={value === option.value ? "true" : "false"}
          onClick={() => onChange(option.value)}
          aria-pressed={value === option.value}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

export function MiniMeter({
  value,
  tone = "mint",
}: {
  value: number;
  tone?: "mint" | "amber" | "ice";
}) {
  const fill =
    tone === "amber"
      ? "linear-gradient(90deg,#c78a2b,#ffd479 60%,#fff0bc)"
      : tone === "ice"
        ? "linear-gradient(90deg,#2f9eaa,#a4e6ff 60%,#e2fbff)"
        : "linear-gradient(90deg,#2fbc88,#8ff29a 55%,#d6ff8a)";
  return (
    <span className="progress-track block">
      <span
        className="progress-fill"
        style={{ width: `${Math.max(0, Math.min(100, value))}%`, background: fill }}
      />
    </span>
  );
}
