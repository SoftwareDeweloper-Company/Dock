import { useEffect, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Home,
  Orbit,
  Pause,
  Play,
  RotateCcw,
  Shield,
  Sparkles,
  Trophy,
  Zap,
} from "lucide-react";
import { cn } from "@/utils/cn";
import { HyperSnakeGame, type EngineOptions, type HudSnapshot } from "@/game/engine";
import { IconButton, Keycap } from "@/components/ui";

const QUALITY_LABEL: Record<EngineOptions["quality"], string> = {
  ultra: "УЛЬТРА",
  balanced: "БАЛАНС",
  lite: "ЛАЙТ",
};

const DIRS: Record<string, [number, number]> = {
  ArrowUp: [0, -1],
  ArrowDown: [0, 1],
  ArrowLeft: [-1, 0],
  ArrowRight: [1, 0],
  w: [0, -1],
  W: [0, -1],
  s: [0, 1],
  S: [0, 1],
  a: [-1, 0],
  A: [-1, 0],
  d: [1, 0],
  D: [1, 0],
  ц: [0, -1],
  Ц: [0, -1],
  ы: [0, 1],
  Ы: [0, 1],
  ф: [-1, 0],
  Ф: [-1, 0],
  в: [1, 0],
  В: [1, 0],
};

export function GameStage({
  options,
  hud,
  onHud,
}: {
  options: EngineOptions;
  hud: HudSnapshot;
  onHud: (hud: HudSnapshot) => void;
}) {
  const hostRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<HyperSnakeGame | null>(null);
  const onHudRef = useRef(onHud);
  const touchRef = useRef<{ x: number; y: number } | null>(null);
  const [deadVisible, setDeadVisible] = useState(false);
  const [showHint, setShowHint] = useState(true);

  useEffect(() => {
    onHudRef.current = onHud;
  }, [onHud]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const host = hostRef.current;
    if (!canvas || !host) return;
    const rect = host.getBoundingClientRect();
    const game = new HyperSnakeGame(
      canvas,
      rect.width || 880,
      rect.height || 560,
      options,
      (snapshot) => onHudRef.current(snapshot)
    );
    gameRef.current = game;
    const observer = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry) return;
      const { width, height } = entry.contentRect;
      if (width > 40 && height > 40) game.resize(width, height);
    });
    observer.observe(host);
    return () => {
      observer.disconnect();
      game.destroy();
      gameRef.current = null;
    };
    // Engine is created once; option updates are applied by the effect below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    gameRef.current?.setOptions(options);
  }, [options]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.tagName === "SELECT" ||
          target.isContentEditable)
      ) {
        return;
      }
      const game = gameRef.current;
      if (!game) return;
      const dir = DIRS[event.key];
      if (dir) {
        event.preventDefault();
        if (game.state === "ready") game.start();
        game.turn(dir[0], dir[1]);
        return;
      }
      if (event.key === " " || event.key === "Spacebar") {
        event.preventDefault();
        if (game.state === "ready" || game.state === "dead") game.start();
        else game.togglePause();
      } else if (event.key === "r" || event.key === "R") {
        event.preventDefault();
        game.restart();
      } else if (event.key === "Escape") {
        event.preventDefault();
        if (game.state === "playing") game.pause();
        else if (game.state === "paused") game.resume();
      }
    }
    window.addEventListener("keydown", onKey, { passive: false });
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (hud.state !== "dead") {
      setDeadVisible(false);
      return;
    }
    const timer = window.setTimeout(() => setDeadVisible(true), 620);
    return () => window.clearTimeout(timer);
  }, [hud.state]);

  useEffect(() => {
    setShowHint(hud.state === "ready" || hud.apples === 0);
  }, [hud.state, hud.apples]);

  const start = () => gameRef.current?.start();
  const pause = () => {
    const game = gameRef.current;
    if (!game) return;
    if (game.state === "ready" || game.state === "dead") game.start();
    else game.togglePause();
  };
  const restart = () => gameRef.current?.restart();
  const menu = () => gameRef.current?.menu();

  const dpad = (x: number, y: number) => {
    const game = gameRef.current;
    if (!game) return;
    if (game.state === "ready") game.start();
    game.turn(x, y);
  };

  const handlePointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    if (event.pointerType !== "mouse") return;
    const game = gameRef.current;
    const host = hostRef.current;
    if (!game || !host) return;
    if (game.state === "ready") {
      game.start();
      return;
    }
    if (game.state !== "playing") return;
    const rect = host.getBoundingClientRect();
    game.steerTowards(event.clientX - rect.left, event.clientY - rect.top);
  };

  const handleTouchStart = (event: React.TouchEvent<HTMLDivElement>) => {
    const touch = event.touches[0];
    if (!touch) return;
    touchRef.current = { x: touch.clientX, y: touch.clientY };
  };
  const handleTouchMove = (event: React.TouchEvent<HTMLDivElement>) => {
    const game = gameRef.current;
    const touch = event.touches[0];
    if (!game || !touch || game.state !== "playing" || !touchRef.current) return;
    const dx = touch.clientX - touchRef.current.x;
    const dy = touch.clientY - touchRef.current.y;
    if (Math.hypot(dx, dy) < 22) return;
    if (Math.abs(dx) > Math.abs(dy)) game.turn(dx > 0 ? 1 : -1, 0);
    else game.turn(0, dy > 0 ? 1 : -1);
    touchRef.current = { x: touch.clientX, y: touch.clientY };
  };
  const handleTouchEnd = () => {
    touchRef.current = null;
  };

  const showOverlay = hud.state === "ready" || hud.state === "paused" || (hud.state === "dead" && deadVisible);
  const comboActive = hud.combo > 1 && hud.state === "playing";
  const fpsTone = hud.fps >= 54 ? "text-mint" : hud.fps >= 38 ? "text-amber" : "text-coral";
  const stateLabel =
    hud.state === "playing"
      ? "LIVE RUN"
      : hud.state === "paused"
        ? "PAUSED"
        : hud.state === "dead"
          ? "SIGNAL LOST"
          : "DEMO FEED";

  return (
    <div className="relative">
      <div className="game-shell">
        <div
          ref={hostRef}
          className="game-shell-inner relative h-[64vh] max-h-[660px] min-h-[430px] w-full sm:h-[66vh] sm:max-h-[700px]"
        >
          <canvas ref={canvasRef} className="stage-canvas" aria-label="Игровое поле гипер-змейки" />
          <div className="stage-scanlines" aria-hidden />
          <div className="stage-vignette" aria-hidden />

          {/* input layer */}
          <div
            className="absolute inset-0 z-10 cursor-crosshair"
            onPointerDown={handlePointerDown}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
            onTouchCancel={handleTouchEnd}
          />

          {/* HUD */}
          <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-2 p-3 sm:p-4">
            <div className="flex flex-col items-start gap-1.5">
              <div className="stat-chip !px-3 !py-1.5">
                <span className="stat-label">Очки</span>
                <span key={hud.score} className="stat-value anim-pop text-neon">
                  {hud.score.toLocaleString("ru-RU")}
                </span>
              </div>
              {comboActive ? (
                <div key={hud.combo} className="combo-chip anim-pop">
                  <Zap size={10} strokeWidth={2.6} />
                  КОМБО ×{hud.combo}
                  <span className="block h-1 w-9 overflow-hidden rounded-full bg-amber/20">
                    <span
                      className="block h-full rounded-full bg-gradient-to-r from-amber to-coral transition-[width] duration-100"
                      style={{ width: `${Math.round(hud.comboFrac * 100)}%` }}
                    />
                  </span>
                </div>
              ) : null}
            </div>

            <div className="flex items-start gap-1.5 sm:gap-2">
              <div className="stat-chip hidden min-[420px]:flex">
                <span className="stat-label">Рекорд</span>
                <span className="stat-value text-amber">{hud.best.toLocaleString("ru-RU")}</span>
              </div>
              <div className="stat-chip">
                <span className="stat-label">Длина</span>
                <span className="stat-value text-ice">{hud.length}</span>
              </div>
              <div className="stat-chip hidden sm:flex">
                <span className="stat-label">Скорость</span>
                <span className="stat-value text-mint">{hud.speed.toFixed(1)}×</span>
              </div>
            </div>
          </div>

          {/* start / pause / game over */}
          {showOverlay && hud.state === "ready" ? (
            <div className="absolute inset-0 z-30 flex items-center justify-center bg-[radial-gradient(circle_at_50%_45%,rgba(5,22,14,0.45),rgba(2,9,6,0.88))] p-3 backdrop-blur-[3px] sm:p-5">
              <div className="overlay-card anim-pop max-h-full overflow-y-auto px-5 py-5 sm:px-7 sm:py-6">
                <div className="relative flex items-center justify-between gap-2">
                  <span className="badge badge-live">
                    <span className="dot-live" /> ЗАБЕГ ГОТОВ
                  </span>
                  <span className="badge">ARENA / 01</span>
                </div>

                <div className="relative mt-4">
                  <div className="eyebrow">Биолюминесцентная аркада</div>
                  <h2 className="num text-neon-grad mt-1.5 text-[34px] font-extrabold leading-[0.88] sm:text-[44px]">
                    HYPER
                    <br />
                    SNAKE
                  </h2>
                  <p className="mt-3 max-w-[38ch] text-[11.5px] leading-relaxed text-fog sm:text-[12.5px]">
                    Собирай пульсирующие яблоки, держи серию и расти. Каждое пятое яблоко — золотое.
                    Один неверный поворот — и сигнал потерян.
                  </p>
                </div>

                <div className="relative mt-4 flex items-center justify-between rounded-xl border border-line/70 bg-shell/55 px-3 py-2">
                  <span className="flex items-center gap-2">
                    <Trophy size={13} className="text-amber" />
                    <span className="mono text-[8.5px] font-semibold tracking-[0.16em] text-fog/70">
                      ЛУЧШИЙ РЕЗУЛЬТАТ
                    </span>
                  </span>
                  <span className="num text-[17px] font-bold text-amber">
                    {hud.best.toLocaleString("ru-RU")}
                  </span>
                </div>

                <button type="button" className="btn-primary relative mt-3 w-full" onClick={start}>
                  <Play size={14} strokeWidth={2.8} fill="currentColor" />
                  Начать забег
                  <span className="mono ml-auto hidden text-[8.5px] font-semibold opacity-55 sm:inline">SPACE</span>
                </button>

                <div className="relative mt-3 flex flex-wrap items-center justify-center gap-x-3 gap-y-1.5">
                  <span className="flex items-center gap-1.5 text-[9px] text-fog/60">
                    <span className="flex gap-0.5">
                      <Keycap>↑</Keycap>
                      <Keycap>↓</Keycap>
                      <Keycap>←</Keycap>
                      <Keycap>→</Keycap>
                    </span>
                    поворот
                  </span>
                  <span className="mono hidden text-[8.5px] tracking-[0.12em] text-fog/45 sm:inline">
                    WASD · SWIPE · CLICK
                  </span>
                </div>
              </div>
            </div>
          ) : null}

          {showOverlay && hud.state === "paused" ? (
            <div className="absolute inset-0 z-30 flex items-center justify-center bg-[rgba(2,10,7,0.68)] p-4 backdrop-blur-[5px]">
              <div className="overlay-card anim-pop w-full max-w-[360px] px-6 py-6 text-center">
                <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-full border border-neon/30 bg-neon/10 text-neon">
                  <Pause size={16} fill="currentColor" />
                </div>
                <div className="eyebrow mt-3">Поле на удержании</div>
                <h2 className="num mt-1 text-[28px] font-extrabold text-ink">ПАУЗА</h2>
                <p className="mt-1.5 text-[11px] text-fog/70">
                  Текущий счёт — <span className="font-bold text-neon">{hud.score.toLocaleString("ru-RU")}</span>
                </p>
                <button type="button" className="btn-primary mt-4 w-full" onClick={pause}>
                  <Play size={14} fill="currentColor" /> Продолжить
                </button>
                <div className="mt-2 flex gap-2">
                  <button type="button" className="btn-glass flex-1 !py-2.5" onClick={restart}>
                    <RotateCcw size={12} /> Заново
                  </button>
                  <button type="button" className="btn-glass flex-1 !py-2.5" onClick={menu}>
                    <Home size={12} /> В меню
                  </button>
                </div>
              </div>
            </div>
          ) : null}

          {showOverlay && hud.state === "dead" ? (
            <div className="absolute inset-0 z-30 flex items-center justify-center bg-[radial-gradient(circle_at_50%_45%,rgba(30,10,8,0.2),rgba(2,9,6,0.86))] p-4 backdrop-blur-[4px]">
              <div className="overlay-card anim-pop w-full max-w-[400px] px-6 py-6 text-center">
                <div className="relative flex items-center justify-center">
                  <span className="badge !text-coral/90 !border-coral/25 !bg-coral/[0.08]">
                    <span className="h-1.5 w-1.5 rounded-full bg-coral shadow-[0_0_10px_rgba(255,123,114,0.9)]" />
                    СИГНАЛ ПОТЕРЯН
                  </span>
                </div>
                {hud.newRecord ? (
                  <div className="record-burst mx-auto mt-3 inline-flex items-center gap-1.5 rounded-full border border-amber/35 bg-amber/10 px-3 py-1">
                    <Sparkles size={11} className="text-amber" />
                    <span className="mono text-[8.5px] font-bold tracking-[0.18em] text-amber">НОВЫЙ РЕКОРД</span>
                  </div>
                ) : null}
                <div className="num text-neon-grad mt-3 text-[48px] font-extrabold leading-none">
                  {hud.score.toLocaleString("ru-RU")}
                </div>
                <div className="label mt-1.5">Очков за забег</div>

                <div className="mt-4 grid grid-cols-3 gap-1.5">
                  {[
                    { label: "Яблоки", value: hud.apples, color: "text-coral" },
                    { label: "Длина", value: hud.length, color: "text-ice" },
                    { label: "Рекорд", value: hud.best, color: "text-amber" },
                  ].map((item) => (
                    <div key={item.label} className="rounded-xl border border-line/60 bg-shell/45 px-2 py-2">
                      <div className={cn("num text-[16px] font-bold", item.color)}>{item.value}</div>
                      <div className="mono mt-0.5 text-[7.5px] uppercase tracking-[0.16em] text-fog/55">
                        {item.label}
                      </div>
                    </div>
                  ))}
                </div>

                <button type="button" className="btn-primary mt-4 w-full" onClick={start}>
                  <RotateCcw size={14} strokeWidth={2.8} /> Ещё забег
                </button>
                <button type="button" className="btn-glass mt-2 w-full !py-2.5" onClick={menu}>
                  <Home size={12} /> Вернуться в меню
                </button>
              </div>
            </div>
          ) : null}

          {/* bottom status strip */}
          <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 flex items-end justify-between gap-2 p-3 sm:p-4">
            <div className="flex flex-wrap items-center gap-1.5">
              <span
                className={cn(
                  "badge",
                  hud.state === "playing" && "badge-live",
                  hud.state === "dead" && "!border-coral/30 !text-coral/90"
                )}
              >
                {hud.state === "playing" ? <span className="dot-live" /> : null}
                {stateLabel}
              </span>
              <span className="badge hidden sm:inline-flex">
                {hud.wrap ? <Orbit size={10} /> : <Shield size={10} />}
                {hud.wrap ? "ТОРУС" : "СТЕНЫ"}
              </span>
              <span className="mono hidden text-[8px] uppercase tracking-[0.16em] text-fog/45 min-[380px]:inline">
                <span className={fpsTone}>{hud.fps}</span> FPS · {QUALITY_LABEL[options.quality]}
              </span>
            </div>

            <div className="pointer-events-auto flex items-center gap-1.5">
              {showHint && hud.state === "playing" && hud.apples === 0 ? (
                <span className="hidden items-center gap-1 md:flex">
                  <Keycap>SPACE</Keycap>
                  <span className="mono text-[8px] tracking-[0.14em] text-fog/50">ПАУЗА</span>
                </span>
              ) : null}
              <IconButton
                label={hud.state === "paused" ? "Продолжить" : "Пауза"}
                onClick={pause}
                className="!h-9 !w-9 !rounded-xl"
              >
                {hud.state === "paused" ? <Play size={13} fill="currentColor" /> : <Pause size={13} fill="currentColor" />}
              </IconButton>
              <IconButton label="Начать заново" onClick={restart} className="!h-9 !w-9 !rounded-xl">
                <RotateCcw size={13} />
              </IconButton>
            </div>
          </div>
        </div>
      </div>

      {/* swipe / pad controls */}
      <div className="mt-3 flex items-center justify-between gap-3 lg:hidden">
        <div className="flex items-end gap-3">
          <div className="grid w-[150px] grid-cols-3 gap-1.5">
            <span />
            <button type="button" className="dpad-btn" aria-label="Вверх" onClick={() => dpad(0, -1)}>
              <ArrowUp size={16} strokeWidth={2.4} />
            </button>
            <span />
            <button type="button" className="dpad-btn" aria-label="Влево" onClick={() => dpad(-1, 0)}>
              <ArrowLeft size={16} strokeWidth={2.4} />
            </button>
            <button type="button" className="dpad-btn" aria-label="Вниз" onClick={() => dpad(0, 1)}>
              <ArrowDown size={16} strokeWidth={2.4} />
            </button>
            <button type="button" className="dpad-btn" aria-label="Вправо" onClick={() => dpad(1, 0)}>
              <ArrowRight size={16} strokeWidth={2.4} />
            </button>
          </div>
          <div className="hidden flex-col gap-1.5 pb-0.5 min-[390px]:flex">
            <span className="mono text-[8px] uppercase tracking-[0.18em] text-fog/50">Свайп или кнопки</span>
            <span className="text-[10px] leading-snug text-fog/70">
              Веди змейку к яблоку
              <br />и не касайся себя.
            </span>
          </div>
        </div>
        <button type="button" className="btn-glass !px-3 !py-2.5" onClick={restart}>
          <RotateCcw size={12} /> Заново
        </button>
      </div>
    </div>
  );
}
